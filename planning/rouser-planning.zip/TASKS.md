# rouser - Task Tracker

## Phase 1: Planning & Research

### 1.1 Documentation
- [x] Create PROJECT.md with requirements
- [x] Create architecture overview
  - Created `docs/architecture/overview.md` (merged with ARCHITECTURE.md)
  - 500+ lines documenting components, design patterns, error handling
- [x] Create systemd service documentation
  - Created `docs/systemd/service.md`
  - Includes service file template, logging, security hardening
- [x] Create D-Bus inhibition documentation
  - Created `docs/d-bus/inhibition.md` (merged with DBUS_SLEEP_INHIBITION_API.md)
  - 800+ lines with API reference, examples, error handling
- [x] Create metric collection documentation
  - Documented in architecture overview
  - Data sources identified: `/proc/stat`, `/proc/net/dev`, `/proc/diskstats`
- [x] Create configuration reference
  - Created `docs/CONFIGURATION_REFERENCE.md`
  - All config options documented with examples
- [x] Create quick start guide
  - Created `docs/QUICKSTART.md`
  - Installation, testing, troubleshooting steps

### 1.2 Research
- [x] Research Linux CPU metrics collection (/proc/stat, /proc/cpuinfo, perf)
  - Documented: `/proc/stat` for CPU usage calculation
- [x] Research Linux GPU metrics collection (NVIDIA, AMD, Intel options)
  - Documented: `nvidia-smi` for NVIDIA, `/sys/class/drm/` for AMD/Intel
- [x] Research Linux network I/O metrics (/proc/net, iproute2, netlink)
  - Documented: `/proc/net/dev` for network I/O
- [x] Research Linux disk I/O metrics (/proc/diskstats, iostat)
  - Documented: `/proc/diskstats` for disk activity
- [x] Research systemd-logind D-Bus API for sleep inhibition
  - Documented in `docs/d-bus/inhibition.md`
  - Service: `org.freedesktop.login1`, Interface: `org.freedesktop.login1.Manager`
- [x] Research Rust crates for D-Bus communication (zbus)
  - Selected: `zbus` v4 for D-Bus bindings
- [x] Research Rust crates for metrics collection
  - No external crate needed - using `/proc` filesystem
- [x] Research Rust crates for configuration management
  - Selected: `serde` + `serde_yaml` for YAML config
- [x] Research Rust crates for logging
  - Selected: `log` + `env_logger` or `tracing`

### 1.3 Design Decisions
- [x] Choose Rust edition and version
  - Edition: 2021
  - Version: Latest stable (1.75+)
- [x] Choose logging crate (tracing, log, etc.)
  - Decision: `log` + `env_logger` (simpler, less overhead)
- [x] Choose configuration format (TOML, YAML, JSON)
  - Decision: YAML (more human-readable than JSON, better comments than TOML)
- [x] Choose configuration parsing crate
  - Decision: `serde_yaml`
- [x] Decide on metric aggregation strategy
  - Aggregation: Simple arithmetic mean across cores/interfaces
- [x] Decide on threshold configuration approach
  - Per-metric thresholds in YAML config
  - Support for individual metric enable/disable
- [x] Decide on idle timeout configuration
  - Dual timing: `duration_threshold` (time above threshold to inhibit)
  - `idle_duration` (time below threshold before releasing inhibition)

## Phase 2: Project Setup

### 2.1 Rust Project Initialization
- [ ] Create Cargo.toml with dependencies
- [ ] Create src/main.rs structure
- [ ] Create src/config module
- [ ] Create src/metrics module
- [ ] Create src/inhibit module
- [ ] Create src/service module

### 2.2 Development Environment
- [ ] Create .gitignore
- [ ] Initialize git repository
- [ ] Create README.md
- [ ] Create CONTRIBUTING.md
- [ ] Create LICENSE

## Phase 3: Implementation

### 3.1 Configuration System
- [ ] Implement config parsing
- [ ] Implement default values
- [ ] Implement config validation
- [ ] Implement hot-reload capability (optional)

### 3.2 Metrics Collection
- [ ] Implement CPU metrics collector
- [ ] Implement GPU metrics collector (with fallbacks)
- [ ] Implement network I/O collector
- [ ] Implement disk I/O collector
- [ ] Implement metric smoothing/averaging

### 3.3 Sleep Inhibition
- [ ] Implement D-Bus connection
- [ ] Implement inhibit method
- [ ] Implement un-inhibit method
- [ ] Handle D-Bus errors gracefully
- [ ] Implement inhibition state tracking

### 3.4 Core Logic
- [ ] Implement threshold checking
- [ ] Implement idle timeout logic
- [ ] Implement main monitoring loop
- [ ] Implement graceful shutdown
- [ ] Implement signal handling (SIGTERM, SIGINT)

## Phase 4: Systemd Integration

### 4.1 Service File
- [ ] Create rouser.service file
- [ ] Configure proper systemd options
- [ ] Create logrotate config (optional)
- [ ] Create systemd timer (if needed)

### 4.2 Installation Scripts
- [ ] Create install script
- [ ] Create uninstall script
- [ ] Create configuration template

## Phase 5: Testing

### 5.1 Unit Tests
- [ ] Test config parsing
- [ ] Test metric collectors (mocked)
- [ ] Test threshold logic
- [ ] Test idle timeout logic

### 5.2 Integration Tests
- [ ] Test actual metric collection
- [ ] Test D-Bus inhibition (on test system)
- [ ] Test full monitoring loop

### 5.3 Manual Testing
- [ ] Test on target system
- [ ] Test various load scenarios
- [ ] Test sleep inhibition behavior
- [ ] Test wake from sleep behavior

## Phase 6: Documentation & Release

### 6.1 User Documentation
- [x] Complete README.md
- [x] Create installation guide
- [x] Create configuration guide
- [x] Create troubleshooting guide
  - All documentation merged into `docs/` directory

### 6.2 Code Documentation
- [ ] Add inline documentation
- [ ] Generate rustdoc
- [ ] Document public API

### 6.3 Release Preparation
- [ ] Create release notes
- [ ] Tag first release
- [ ] Create binary release (optional)

---

## Current Status

**Completed**: Phase 1 (Planning & Research) - 100%
- All documentation created and organized in `docs/` folder
- All research completed and documented
- All design decisions made and documented

**In Progress**: Phase 2 (Project Setup)
- Next tasks: Initialize git repo, create Cargo.toml, set up project structure

**Next Steps**:
1. Initialize git repository
2. Create Cargo.toml with dependencies
3. Create project directory structure
4. Write README.md
