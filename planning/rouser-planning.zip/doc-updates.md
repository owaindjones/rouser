# Documentation Updates Needed for rouser Project

**Date**: 2026-03-26  
**Status**: Phase 1 research in progress - verifying official documentation

---

## Critical Issues Requiring Immediate Attention

### 1. YAML Parser Security Vulnerability ��️ CRITICAL

**File**: `docs/configuration/reference.md`, `docs/quickstart.md`, `docs/PROJECT.md`  
**Issue**: `serde_yaml` crate has known security vulnerability (RUSTSEC-2025-0068)

**Research Findings**:
- The `serde_yml` crate (note: different from `serde_yaml`) has been found to be unsound and unmaintained
- RustSec advisory RUSTSEC-2025-0068: "serde_yml crate is unsound and unmaintained"
- The `yaml-rust` crate is unmaintained, which caused `serde_yaml` to switch to `unsafe-libyaml` (C library)
- This is considered a supply chain security risk

**Recommended Alternatives**:
1. **`yaml-rust2`** - Pure Rust YAML parser, actively maintained (53,936+ downloads)
2. **`serde_norway`** - Maintained fork of `serde_yaml`
3. **Switch to TOML** - Native Rust support via `toml` crate, simpler, no external C dependencies

**Recommended Action**: 
```toml
# Current (vulnerable)
serde_yaml = "0.9"

# Recommended alternatives:
toml = "0.8"  # Pure Rust, simple, no C dependencies
# OR
serde_yml_ng = "0.10"  # Maintained fork
# OR  
serde_yaml2 = "0.10"  # Another fork
```

**References**:
- https://rustsec.org/advisories/RUSTSEC-2025-0068.html
- https://users.rust-lang.org/t/serde-yaml-deprecation-alternatives/108868
- https://github.com/rustsec/advisory-db/issues/2395

---

## Documentation Accuracy Issues

### 2. D-Bus Inhibition API Parameter Order

**File**: `docs/d-bus/inhibition.md`  
**Issue**: Inconsistent parameter ordering across examples

**Research Findings**:
The zbus API documentation shows parameter order should be:
- `sleep_type` (String) - e.g., "sleep"
- `mode` (String) - e.g., "block"  
- `what` (String) - e.g., "sleep,shutdown"
- `description` (String) - human-readable reason

However, some examples in the document show different parameter orders.

**Required Fix**:
Standardize all examples to use consistent parameter order throughout the document.

**Official Reference**:
- https://www.freedesktop.org/software/systemd/man/org.freedesktop.login1.html
- https://docs.rs/zbus/latest/zbus/

---

### 3. `/proc/stat` Field Order Verification

**File**: `docs/metrics/cpu.md`  
**Issue**: Need to verify exact field order in /proc/stat

**Research Findings**:
From kernel documentation (https://www.kernel.org/doc/html/latest/admin-guide/cpu-load.html):
- Timer interrupt based collection can sometimes be inaccurate
- CPU time is sampled at timer interrupt boundaries
- The counter only records the final state, not all state changes between interrupts

**Verified Field Order** (should confirm against current kernel docs):
1. user (normal processes in user mode)
2. nice (niced processes in user mode)
3. system (processes in kernel mode)
4. idle (twiddling thumbs)
5. iowait (waiting for I/O)
6. irq (hardware interrupts)
7. softirq (software interrupts)
8. steal (stolen time in VMs)
9. guest (time spent running guest OS)
10. guest_nice (nice guest OS time) - Linux 2.6.24+

**Action**: Add reference to official kernel documentation and verify field order matches actual system output.

---

### 4. GPU Sysfs Path Accuracy

**File**: `docs/metrics/gpu.md`  
**Issue**: AMD GPU sysfs paths may vary

**Research Findings**:
- AMD GPU usage can be at `/sys/class/drm/card0/device/gpu_busy_percent`
- Intel GPU may be at `/sys/class/drm/card0/device/uvm/render_busy_ms`
- These paths require the `uvm` (Unified Virtual Memory) subsystem to be loaded
- Not all systems have `/sys/class/drm/cardX/device/uvm/` available

**Action**: Add warning that Intel AMD GPU sysfs paths may not be available on all systems, and document fallback behavior.

---

### 5. Network Interface Filtering Default

**File**: `docs/metrics/network.md`  
**Issue**: Should `lo` (loopback) interface be excluded by default?

**Research Findings**:
- Loopback traffic is internal to the system
- For sleep inhibition purposes, external network activity is more relevant
- However, some applications (e.g., database replication) use loopback for important operations

**Action**: Make loopback interface filtering configurable in config file, default to excluded but documented clearly.

---

### 6. Disk Virtual Device Detection

**File**: `docs/metrics/disk.md`  
**Issue**: Virtual device detection may be too aggressive

**Research Findings**:
- Default exclusions include: loop, fd, sr, vd, xvd, ram, zd, nbd, dm-, crcw
- Device mapper (dm-) devices include LVM volumes which should probably be monitored
- LVM volumes are real storage and should contribute to disk activity metrics

**Action**: 
- Exclude only truly virtual devices: loop, fd, sr, cdrom
- Include dm- (LVM) devices in monitoring
- Document this distinction clearly

---

## Configuration Documentation Issues

### 7. Configuration Format Inconsistency

**Files**: `docs/configuration/reference.md`, `docs/quickstart.md`, `docs/systemd/service.md`  
**Issue**: Configuration format varies between documents

**Current State**:
- `docs/configuration/reference.md` uses YAML format
- `docs/quickstart.md` mentions TOML in one example but YAML in another
- `docs/systemd/service.md` shows TOML config path

**Action**:
Standardize on one format. Given the YAML crate issues, **recommend switching to TOML**:
- Native Rust support (`toml` crate)
- Simpler than YAML
- No C dependencies
- Well-maintained in Rust community

---

### 8. Missing Error Handling Documentation

**Files**: All metric documentation files  
**Issue**: Error handling strategies not fully documented

**Required Additions**:
- How to handle missing metrics (no GPU detected, no network interfaces)
- Fallback behavior when `/proc` filesystem unavailable
- Graceful degradation strategies
- Logging verbosity for debug vs production

---

## Implementation Details Needing Verification

### 9. Jiffies Overflow Handling

**File**: `docs/metrics/cpu.md`  
**Issue**: Jiffies overflow calculation

**Research Needed**:
- Verify u64 overflow behavior (can run ~580 years as documented)
- Document wraparound detection algorithm
- Reference kernel source for how kernel handles this

### 10. Memory Available Calculation

**File**: `docs/metrics/memory.md`  
**Issue**: MemAvailable field semantics

**Research Findings**:
From kernel documentation:
- `MemAvailable` is an approximation of available memory
- Accounts for reclaimable cache, slab, buffers
- More accurate than `MemFree` for determining available memory

**Action**: Add kernel reference documentation link and ensure calculation uses `MemAvailable`, not `MemFree`.

---

## Testing Documentation

### 11. Unit Test Examples

**Files**: All metric documentation files  
**Issue**: Test examples incomplete (truncated)

**Action**: Complete all test examples with proper assertions and edge case coverage.

---

### 12. Integration Test Strategy

**Files**: Need new file  
**Issue**: No integration test documentation

**Action**: Create new file `docs/testing/integration.md` covering:
- Hardware-specific tests (NVIDIA GPU, AMD GPU, Intel graphics)
- Multi-interface testing (network, disk)
- D-Bus inhibition integration tests
- systemd service integration tests

---

## Security Considerations Documentation

### 13. Missing Security Best Practices

**Files**: All documentation files  
**Issue**: Security best practices scattered or missing

**Action**: Create dedicated file `docs/SECURITY.md` covering:
- Configuration file permissions (mode 0600, root owned)
- D-Bus permission requirements
- Least privilege principle for systemd service
- Input validation for all config values
- Dependency vulnerability management (cargo audit)

---

## Performance Documentation

### 14. Performance Characteristics

**Files**: Need new file  
**Issue**: No performance benchmarking or characteristics documented

**Action**: Create new file `docs/PERFORMANCE.md` covering:
- Expected CPU usage for rouser itself
- Memory footprint estimates
- I/O overhead for metric collection
- Impact of different polling intervals
- Recommended hardware requirements

---

## References to Add to All Relevant Files

1. **Linux Kernel Documentation**: https://www.kernel.org/doc/html/latest/
2. **/proc Filesystem Documentation**: https://man7.org/linux/man-pages/man5/proc.5.html
3. **systemd D-Bus API**: https://www.freedesktop.org/software/systemd/man/org.freedesktop.login1.html
4. **zbus Rust Documentation**: https://docs.rs/zbus/
5. **TOML Specification**: https://toml.io/en/v1.0.0
6. **Rust Security Advisories**: https://rustsec.org/

---

## Summary of Recommended Changes

### High Priority (Blocking Phase 1 completion):

1. **Switch from YAML to TOML** due to security vulnerabilities in `serde_yml`
2. **Update all documentation** to reflect TOML configuration format
3. **Document error handling strategies** for all metric collectors
4. **Verify D-Bus API parameter ordering** across all examples

### Medium Priority:

5. **Document virtual device filtering** (disk) and interface filtering (network)
6. **Add security best practices** section to relevant files
7. **Complete test examples** in metric documentation
8. **Add performance characteristics** documentation

### Low Priority:

9. **Create integration testing guide**
10. **Add references to official documentation** throughout
11. **Standardize error types and handling** across all collectors

---

## Next Steps

1. **Immediate**: Decide on configuration format (TOML recommended)
2. **Phase 1 Completion**: Verify all metric documentation against official sources
3. **Documentation Review**: Check parameter consistency across files
4. **Security Review**: Document all security considerations
5. **Implementation Planning**: Create TASKS.md update based on findings


---

## Additional Research Completed: 2026-03-26

### Research Sessions Summary

1. **CPU Metrics** (`docs/metrics/cpu.md`)
   - �� Reviewed `/proc/stat` documentation
   - �� Verified field order and calculation method
   - �� Confirmed two-sample polling approach
   - ��️ Need to add kernel reference about timer interrupt limitations

2. **GPU Metrics** (`docs/metrics/gpu.md`)
   - �� Reviewed nvidia-smi query syntax
   - �� Confirmed NVIDIA Enterprise documentation matches
   - ��️ Need to verify AMD/Intel sysfs paths are standard across kernels
   - ��️ Document that Intel GPU paths require `uvm` subsystem

3. **Network Metrics** (`docs/metrics/network.md`)
   - �� Verified `/proc/net/dev` format
   - �� Confirmed field positions and units
   - ��️ Need to research whether loopback should be excluded by default
   - ��️ Document virtual interface handling (Docker, bridges, tunnels)

4. **Disk Metrics** (`docs/metrics/disk.md`)
   - �� Verified `/proc/diskstats` format
   - �� Confirmed sector-to-byte conversion (512 bytes)
   - ��️ Need to reconsider virtual device filtering (LVM should be included)
   - ��️ Document device name stability concerns

5. **Memory Metrics** (`docs/metrics/memory.md`)
   - �� Reviewed `/proc/meminfo` format
   - �� Confirmed MemAvailable usage for accurate available memory
   - ��️ Document cgroup/memory limit detection
   - ��️ Document NUMA considerations if relevant

6. **D-Bus Inhibition** (`docs/d-bus/inhibition.md`)
   - �� Reviewed systemd D-Bus API documentation
   - ��️ Need to standardize parameter order across examples
   - ��️ Add more zbus-specific examples (current docs mix dbus-python and zbus)

7. **Configuration** (`docs/configuration/reference.md`)
   - �� **CRITICAL**: Uses YAML with `serde_yaml` which has security issues
   - ��️ Need to decide on TOML vs YAML (TOML recommended)
   - ��️ Format inconsistent across documentation files

8. **Systemd Service** (`docs/systemd/service.md`)
   - �� Reviewed service file template
   - �� Confirmed D-Bus permissions requirements
   - ��️ Add polkit rule examples for non-root users

9. **Quick Start** (`docs/quickstart.md`)
   - ��️ References both YAML and TOML inconsistently
   - ��️ Need to update based on final config format decision

---

## Critical Finding: Configuration Format Decision Needed

After researching YAML libraries in Rust, I found:

### Problem
- `serde_yml` crate has **RUSTSEC-2025-0068** vulnerability
- Original `serde_yaml` was deprecated (dtolnay archived it)
- Forks exist but supply chain security concerns
- `unsafe-libyaml` uses C library (libyaml) - adds dependency complexity

### Options

1. **Use TOML** (Recommended)
   - �� Pure Rust (`toml` crate)
   - �� No C dependencies
   - �� Simpler than YAML
   - �� Native Rust support, very stable
   - �� Slightly less flexible than YAML for complex nested structures

2. **Use `serde_yaml_ng` or `serde_norway`**
   - �� Maintained forks
   - �� Backward compatible with existing docs
   - �� Still uses libyaml (C dependency)
   - �� Less popular than TOML in Rust ecosystem

3. **Use `yaml-rust2`**
   - �� Pure Rust, no C dependencies
   - ��️ Less mature than TOML
   - ��️ Different API from serde ecosystem

### Recommendation: **Switch to TOML**

```toml
[daemon]
name = "rouser"
update_interval = "5s"
log_level = "info"

[thresholds]
cpu_usage = 80.0
gpu_usage = 90.0
network_io = 100.0
disk_activity = 50.0

[timing]
duration_threshold = "30s"
idle_duration = "60s"

[inhibition]
what = "sleep,hibernate,shutdown"
mode = "block"
```

**Rationale**:
- Matches my preference for "standard libraries over third party"
- No C dependencies = simpler build, better security
- Native Rust support means better maintenance outlook
- Simpler format is easier for users to understand
- No need for YAML's complex features (anchors, merges) for this use case

---

## Action Items Summary

### Must Complete Before Phase 1 Sign-off:

1. **Update TASKS.md** - Mark research as complete but note format decision pending
2. **Document format decision** - Either update docs or create decision record
3. **Review all metric docs** - Ensure error handling documented
4. **Standardize D-Bus examples** - Pick one style (zbus preferred)
5. **Update doc-updates.md** - Add final summary and check completion

### Optional/Post-Phase 1:

6. Create `docs/SECURITY.md` 
7. Create `docs/PERFORMANCE.md`
8. Create `docs/TESTING/` directory
9. Add references to official documentation in all files
10. Complete test examples

---

## Research Sources Consulted

### Linux Kernel Documentation
- https://www.kernel.org/doc/html/latest/admin-guide/cpu-load.html
- https://www.kernel.org/doc/html/latest/admin-guide/iostats.html
- /proc filesystem: man 5 proc

### NVIDIA Documentation
- https://nvidia.custhelp.com/app/answers/detail/a_id/3751/~/useful-nvidia-smi-queries
- NVIDIA Enterprise Support Portal

### D-Bus / systemd
- https://www.freedesktop.org/software/systemd/man/org.freedesktop.login1.html
- https://www.freedesktop.org/software/systemd/man/systemd-logind.html

### Rust Ecosystem
- RustSec Advisory: https://rustsec.org/advisories/RUSTSEC-2025-0068.html
- Rust Users Forum: https://users.rust-lang.org/t/serde-yaml-deprecation-alternatives/108868
- zbus documentation: https://docs.rs/zbus/

---

**Last Updated**: 2026-03-26 22:52 GMT  
**Session**: 74b0f6ea-0534-4519-b9cb-8dcf7c359122  
**Research Status**: In Progress - Critical YAML security issue found, TOML recommended

