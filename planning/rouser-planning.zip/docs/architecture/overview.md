# rouser Architecture Overview

## System Design

rouser is a daemon that monitors system metrics and inhibits sleep when thresholds are exceeded. The architecture is designed to be:

- **Modular**: Separate modules for config, metrics, inhibition, and core logic
- **Efficient**: Minimal resource usage when idle
- **Reliable**: Graceful error handling and state recovery
- **Configurable**: All thresholds and timeouts configurable

## Component Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                     rouser Daemon                            │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐  │
│  │   Config     │    │   Metrics    │    │   Inhibit    │  │
│  │   Module     │    │   Module     │    │   Module     │  │
│  └──────┬───────┘    └──────┬───────┘    └──────┬───────┘  │
│         │                   │                   │          │
│         └───────────────────┼───────────────────┘          │
│                             │                              │
│                    ┌────────▼────────┐                     │
│                    │   Core Logic    │                     │
│                    │   (Main Loop)   │                     │
│                    └────────┬────────┘                     │
│                             │                              │
│                    ┌────────▼────────┐                     │
│                    │  Signal Handler │                     │
│                    └─────────────────┘                     │
│                                                              │
└─────────────────────────────────────────────────────────────┘
         │                    │                    │
         ▼                    ▼                    ▼
    config.yaml           /proc/*             D-Bus API
                                              (org.freedesktop.login1)
```

## Detailed Component Design

### 1. Metric Collector

**Responsibility**: Gather system metrics from `/proc` and other sources

**Key Metrics**:
- CPU usage (aggregate across all cores)
- GPU usage (via `nvidia-smi` or `/sys/class/drm`)
- Network I/O (bytes sent/received per second)
- Disk activity (read/write bytes per second)

**Data Sources**:
- CPU: `/proc/stat`
- GPU: `nvidia-smi` (NVIDIA) or `/sys/class/drm/` (AMD/Intel)
- Network: `/proc/net/dev`
- Disk: `/proc/diskstats`

```rust
pub struct MetricCollector {
    update_interval: Duration,
}

impl MetricCollector {
    pub async fn collect_metrics(&self) -> Result<SystemMetrics> {
        Ok(SystemMetrics {
            cpu_usage: self.collect_cpu_usage().await?,
            gpu_usage: self.collect_gpu_usage().await?,
            network_io: self.collect_network_io().await?,
            disk_activity: self.collect_disk_activity().await?,
        })
    }
}
```

### 2. Threshold Manager

**Responsibility**: Compare metrics against thresholds and determine if inhibition is needed

**Configuration**:
```yaml
thresholds:
  cpu_usage: 80.0        # Percentage
  gpu_usage: 90.0        # Percentage
  network_io: 100.0      # Mbps
  disk_activity: 50.0    # MB/s

timing:
  duration_threshold: 30  # Seconds metric must exceed threshold
  idle_duration: 60       # Seconds all metrics must be below threshold
```

**Hysteresis Logic**:
- Track when metrics go above threshold (high water mark)
- Track when metrics go below threshold (low water mark)
- Only inhibit if metric stays above threshold for `duration_threshold`
- Only release inhibition if all metrics stay below threshold for `idle_duration`

```rust
pub struct ThresholdManager {
    thresholds: Thresholds,
    duration_threshold: Duration,
    idle_duration: Duration,
    high_water_mark: HashMap<MetricType, Instant>,
    low_water_mark: HashMap<MetricType, Instant>,
}

impl ThresholdManager {
    pub fn should_inhibit(&mut self, metrics: &SystemMetrics) -> bool {
        // Check if any metric exceeds threshold
        if metrics.exceeds_thresholds(&self.thresholds) {
            // Track when we went high
            self.high_water_mark = metrics.high_water_times(&self.high_water_mark);
            return true;
        }
        
        // Check if we've been idle long enough
        if self.has_been_idle_long_enough() {
            return false;
        }
        
        // Still in transition phase
        false
    }
}
```

### 3. Sleep Inhibitor

**Responsibility**: Manage D-Bus sleep inhibition locks

**Key Features**:
- RAII pattern for file descriptor management
- Automatic inhibition release on drop
- Logging of inhibition events
- Error handling for D-Bus operations

**Implementation**:
```rust
pub struct SleepInhibitor {
    fd: File,
    cookie: String,
    what: String,
    description: String,
}

impl SleepInhibitor {
    pub async fn new(what: &str, description: &str) -> Result<Self> {
        let connection = Connection::system().await?;
        
        let proxy = connection
            .object_proxy("org.freedesktop.login1", "/org/freedesktop/login1")
            .typed::<(), (RawFd, String)>();
        
        let (fd, cookie) = proxy
            .call("Inhibit", &("sleep", "block", what, description))
            .await?;
        
        let file = unsafe { File::from_raw_fd(fd) };
        
        Ok(Self {
            fd: file,
            cookie,
            what: what.to_string(),
            description: description.to_string(),
        })
    }
    
    pub fn release(&mut self) {
        // File dropped, inhibition released
    }
}

impl Drop for SleepInhibitor {
    fn drop(&mut self) {
        log::info!("Releasing sleep inhibition: {}", self.cookie);
    }
}
```

### 4. Main Daemon Loop

**Responsibility**: Orchestrate metric collection, threshold checking, and sleep inhibition

**State Machine**:
```
┌──────────────┐
│    IDLE      │◄─────┐
└──────┬───────┘      │
       │ metrics      │ all metrics
       │ exceed       │ below threshold
       ▼               │
┌──────────────┐      │
│ INHIBITING   │──────┘
│              │
│ - Collect    │
│ - Check      │
│ - Maintain   │
│   inhibitor  │
└──────────────┘
```

**Implementation**:
```rust
pub struct Daemon {
    collector: MetricCollector,
    threshold_manager: ThresholdManager,
    inhibitor: Option<SleepInhibitor>,
    config: Config,
}

impl Daemon {
    pub async fn run(&mut self) -> Result<()> {
        let mut interval = tokio::time::interval(self.config.update_interval);
        
        loop {
            interval.tick().await;
            
            let metrics = self.collector.collect_metrics().await?;
            let should_inhibit = self.threshold_manager.should_inhibit(&metrics);
            
            match (should_inhibit, self.inhibitor.is_some()) {
                (true, false) => {
                    // Start inhibiting
                    self.start_inhibition(&metrics).await?;
                }
                (false, true) => {
                    // Stop inhibiting
                    self.stop_inhibition().await?;
                }
                _ => {}
            }
        }
    }
}
```

## Configuration System

### Config File Structure

```yaml
# /etc/rouser/config.yaml

daemon:
  name: "rouser"
  update_interval: 5s
  log_level: info

thresholds:
  cpu_usage: 80.0        # Percentage (0-100)
  gpu_usage: 90.0        # Percentage (0-100)
  network_io: 100.0      # Mbps
  disk_activity: 50.0    # MB/s

timing:
  duration_threshold: 30  # Seconds metric must stay above threshold
  idle_duration: 60       # Seconds all metrics must stay below threshold

inhibition:
  what: "sleep,hibernate,shutdown"
  mode: "block"
```

### Config Loading

```rust
#[derive(Deserialize, Debug, Clone)]
pub struct Config {
    pub daemon: DaemonConfig,
    pub thresholds: Thresholds,
    pub timing: TimingConfig,
    pub inhibition: InhibitionConfig,
}

impl Config {
    pub fn load(path: &str) -> Result<Self> {
        let content = fs::read_to_string(path)?;
        let config: Config = serde_yaml::from_str(&content)?;
        Ok(config)
    }
    
    pub async fn reload(&mut self, path: &str) -> Result<()> {
        *self = Self::load(path)?;
        log::info!("Configuration reloaded");
        Ok(())
    }
}
```

## Error Handling Strategy

### Error Types

```rust
#[derive(Error, Debug)]
pub enum RouserError {
    #[error("Metric collection failed: {0}")]
    MetricCollection(#[from] MetricError),
    
    #[error("D-Bus error: {0}")]
    Dbus(#[from] zbus::Error),
    
    #[error("Configuration error: {0}")]
    Config(#[from] ConfigError),
    
    #[error("Permission denied: {0}")]
    PermissionDenied(String),
    
    #[error("IO error: {0}")]
    Io(#[from] io::Error),
}
```

### Error Recovery

```rust
impl Daemon {
    async fn run_with_recovery(&mut self) -> Result<()> {
        loop {
            match self.run_once().await {
                Ok(()) => {}
                Err(RouserError::MetricCollection(e)) => {
                    log::error!("Metric collection failed, retrying: {}", e);
                    tokio::time::sleep(Duration::from_secs(1)).await;
                    continue;
                }
                Err(RouserError::Dbus(e)) => {
                    log::error!("D-Bus error: {}", e);
                    // Could be temporary, retry after delay
                    tokio::time::sleep(Duration::from_secs(5)).await;
                    continue;
                }
                Err(e) => {
                    log::error!("Fatal error: {}", e);
                    return Err(e);
                }
            }
        }
    }
}
```

## Logging Strategy

### Log Levels

- `ERROR`: Fatal errors, permission denied
- `WARN`: Recoverable errors, configuration issues
- `INFO`: State changes (inhibit start/stop), config reload
- `DEBUG`: Metric values, detailed operation info

### Log Format

```rust
// Structured logging with metadata
log::info!(
    target: "rouser",
    "sleep_inhibited",
    cookie = %inhibitor_cookie,
    what = %what,
    metrics = ?metrics
);
```

## Resource Management

### File Descriptor Management

- Use RAII pattern with `Drop` trait
- Wrap D-Bus file descriptor in `File` struct
- Automatic cleanup on daemon shutdown

### Memory Management

- Bounded metric buffers (last N samples)
- No long-term metric storage
- Configuration loaded once, reloaded on SIGHUP

### CPU Efficiency

- Polling interval configurable (default 5s)
- No busy-waiting
- Efficient `/proc` parsing

## Security Considerations

### Permissions

- Requires read access to `/proc` (usually available)
- Requires D-Bus system bus access
- Add user to `login` group or run as root

### Configuration Security

- Config file should be readable only by root
- Validate all configuration values
- Sanitize description strings

### Error Handling

- Don't leak sensitive information in errors
- Log errors appropriately
- Graceful degradation on partial failures

## Testing Strategy

### Unit Tests

```rust
#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_threshold_evaluation() {
        let thresholds = Thresholds {
            cpu_usage: 80.0,
            gpu_usage: 90.0,
            network_io: 100.0,
            disk_activity: 50.0,
        };
        
        let metrics = SystemMetrics {
            cpu_usage: 85.0,
            gpu_usage: 70.0,
            network_io: 50.0,
            disk_activity: 25.0,
        };
        
        assert!(metrics.exceeds_thresholds(&thresholds));
        assert_eq!(metrics.exceeding_metric(), Some("cpu_usage"));
    }
    
    #[test]
    fn test_hysteresis_logic() {
        // Test that brief spikes don't trigger inhibition
        // Test that sustained activity triggers inhibition
    }
}
```

### Integration Tests

```rust
#[tokio::test]
async fn test_inhibitor_lifecycle() {
    let inhibitor = SleepInhibitor::new("sleep", "Test").await.unwrap();
    
    // Verify inhibitor is active
    let inhibitors = list_inhibitors("sleep").await.unwrap();
    assert!(inhibitors.iter().any(|i| i.cookie == inhibitor.cookie()));
    
    // Drop inhibitor
    drop(inhibitor);
    
    // Verify inhibitor is released
    let inhibitors = list_inhibitors("sleep").await.unwrap();
    assert!(!inhibitors.iter().any(|i| i.cookie == inhibitor.cookie()));
}
```

## Performance Considerations

### Time Complexity

- Metric collection: O(n) where n = number of cores/interfaces
- Threshold evaluation: O(1) - constant number of metrics
- D-Bus call: O(1) - single method call

### Space Complexity

- Metric storage: O(1) - fixed number of metrics
- History buffers: O(k) where k = configured buffer size
- Configuration: O(1) - single config object

### Optimization Opportunities

1. **Batch metric collection**: Read all `/proc` files in parallel
2. **Caching**: Cache metric values between checks
3. **Adaptive polling**: Increase interval when idle
4. **Incremental updates**: Only read changed `/proc` entries

## Future Enhancements

1. **GPU support**: Add support for AMD/Intel GPUs
2. **Custom metrics**: Allow user-defined metric sources
3. **Web UI**: Dashboard for monitoring and configuration
4. **Notification**: Alert when sleep is inhibited
5. **Multi-instance**: Support multiple inhibition contexts
6. **Machine learning**: Adaptive threshold adjustment

## References

- [systemd D-Bus API](https://www.freedesktop.org/software/systemd/man/org.freedesktop.login1.html)
- [zbus Documentation](https://docs.rs/zbus/)
- [Linux /proc filesystem](https://www.kernel.org/doc/Documentation/filesystems/proc.txt)
- [Rust Best Practices](https://rust-lang.github.io/api-guidelines/)
# Rouser Daemon Architecture

## System Overview

Rouser is a Rust daemon that monitors system metrics and prevents sleep when activity thresholds are exceeded. It runs as a systemd service on Linux systems.

```
┌─────────────────────────────────────────────────────────────┐
│                     Rouser Daemon                           │
├─────────────────────────────────────────────────────────────┤
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │  Metric      │  │  Threshold   │  │  Sleep       │      │
│  │  Collector   │──│  Manager     │──│  Inhibitor   │      │
│  │              │  │              │  │              │      │
│  │  - CPU       │  │  - Config    │  │  - D-Bus     │      │
│  │  - GPU       │  │  - Duration  │  │  - FD mgmt   │      │
│  │  - Network   │  │  - Hysteresis│  │  - Logging   │      │
│  │  - Disk      │  │              │  │              │      │
│  └──────────────┘  └──────────────┘  └──────────────┘      │
│         │                   │                  │            │
│         ▼                   ▼                  ▼            │
│  ┌──────────────────────────────────────────────────┐     │
│  │              Decision Engine                     │     │
│  │  - Aggregate metrics                             │     │
│  │  - Apply thresholds                              │     │
│  │  - Track duration above threshold                │     │
│  │  - Apply hysteresis                              │     │
│  └──────────────────────────────────────────────────┘     │
│                            │                               │
│                            ▼                               │
│  ┌──────────────────────────────────────────────────┐     │
│  │              Configuration                       │     │
│  │  - YAML config file                              │     │
│  │  - Runtime reloadable                            │     │
│  └──────────────────────────────────────────────────┘     │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
                    ┌───────────────┐
                    │  systemd      │
                    │  Service      │
                    └───────────────┘
                            │
                            ▼
                    ┌───────────────┐
                    │  D-Bus        │
                    │  System Bus   │
                    └───────────────┘
                            │
                            ▼
                    ┌───────────────┐
                    │  systemd-     │
                    │  logind       │
                    └───────────────┘
```

## Component Design

### 1. Metric Collector (`metric_collector`)

**Responsibility**: Gather system metrics from `/proc` and other sources

**Key Metrics**:
- CPU usage (aggregate across all cores)
- GPU usage (via `nvidia-smi` or `/sys/class/drm`)
- Network I/O (bytes sent/received per second)
- Disk activity (read/write bytes per second)

**Implementation**:
```rust
pub struct MetricCollector {
    update_interval: Duration,
}

impl MetricCollector {
    pub async fn collect_metrics(&self) -> Result<SystemMetrics> {
        Ok(SystemMetrics {
            cpu_usage: self.collect_cpu_usage().await?,
            gpu_usage: self.collect_gpu_usage().await?,
            network_io: self.collect_network_io().await?,
            disk_activity: self.collect_disk_activity().await?,
        })
    }
}
```

**Data Sources**:
- CPU: `/proc/stat`
- GPU: `nvidia-smi` (NVIDIA) or `/sys/class/drm/` (AMD/Intel)
- Network: `/proc/net/dev`
- Disk: `/proc/diskstats`

### 2. Threshold Manager (`threshold_manager`)

**Responsibility**: Compare metrics against thresholds and determine if inhibition is needed

**Configuration**:
```yaml
thresholds:
  cpu_usage: 80.0        # Percentage
  gpu_usage: 90.0        # Percentage
  network_io: 100.0      # Mbps
  disk_activity: 50.0    # MB/s

duration_threshold: 30   # Seconds metric must exceed threshold
idle_duration: 60        # Seconds all metrics must be below threshold
```

**Hysteresis Logic**:
```rust
pub struct ThresholdManager {
    thresholds: Thresholds,
    duration_threshold: Duration,
    idle_duration: Duration,
    high_water_mark: HashMap<MetricType, Instant>,
    low_water_mark: HashMap<MetricType, Instant>,
}

impl ThresholdManager {
    pub fn should_inhibit(&mut self, metrics: &SystemMetrics) -> bool {
        // Check if any metric exceeds threshold
        if metrics.exceeds_thresholds(&self.thresholds) {
            // Track when we went high
            self.high_water_mark = metrics.high_water_times(&self.high_water_mark);
            return true;
        }
        
        // Check if we've been idle long enough
        if self.has_been_idle_long_enough() {
            return false;
        }
        
        // Still in transition phase
        false
    }
}
```

### 3. Sleep Inhibitor (`sleep_inhibitor`)

**Responsibility**: Manage D-Bus sleep inhibition locks

**Key Features**:
- RAII pattern for file descriptor management
- Automatic inhibition release on drop
- Logging of inhibition events
- Error handling for D-Bus operations

**Implementation**:
```rust
pub struct SleepInhibitor {
    fd: File,
    cookie: String,
    what: String,
    description: String,
}

impl SleepInhibitor {
    pub async fn new(what: &str, description: &str) -> Result<Self> {
        let connection = Connection::system().await?;
        
        let proxy = connection
            .object_proxy("org.freedesktop.login1", "/org/freedesktop/login1")
            .typed::<(), (RawFd, String)>();
        
        let (fd, cookie) = proxy
            .call("Inhibit", &("sleep", "block", what, description))
            .await?;
        
        let file = unsafe { File::from_raw_fd(fd) };
        
        Ok(Self {
            fd: file,
            cookie,
            what: what.to_string(),
            description: description.to_string(),
        })
    }
    
    pub fn release(&mut self) {
        // File dropped, inhibition released
    }
}

impl Drop for SleepInhibitor {
    fn drop(&mut self) {
        log::info!("Releasing sleep inhibition: {}", self.cookie);
    }
}
```

### 4. Main Daemon Loop (`daemon`)

**Responsibility**: Orchestrate metric collection, threshold checking, and sleep inhibition

**State Machine**:
```
┌──────────────┐
│    IDLE      │◄─────┐
└──────┬───────┘      │
       │ metrics      │ all metrics
       │ exceed       │ below threshold
       ▼               │
┌──────────────┐      │
│ INHIBITING   │──────┘
│              │
│ - Collect    │
│ - Check      │
│ - Maintain   │
│   inhibitor  │
└──────────────┘
```

**Implementation**:
```rust
pub struct Daemon {
    collector: MetricCollector,
    threshold_manager: ThresholdManager,
    inhibitor: Option<SleepInhibitor>,
    config: Config,
}

impl Daemon {
    pub async fn run(&mut self) -> Result<()> {
        let mut interval = tokio::time::interval(self.config.update_interval);
        
        loop {
            interval.tick().await;
            
            let metrics = self.collector.collect_metrics().await?;
            let should_inhibit = self.threshold_manager.should_inhibit(&metrics);
            
            match (should_inhibit, self.inhibitor.is_some()) {
                (true, false) => {
                    // Start inhibiting
                    self.start_inhibition(&metrics).await?;
                }
                (false, true) => {
                    // Stop inhibiting
                    self.stop_inhibition().await?;
                }
                _ => {}
            }
        }
    }
    
    async fn start_inhibition(&mut self, metrics: &SystemMetrics) -> Result<()> {
        let description = format!(
            "Rouser: {} above threshold",
            metrics.exceeding_metric()
        );
        
        self.inhibitor = Some(SleepInhibitor::new(
            "sleep,hibernate,shutdown",
            &description
        ).await?);
        
        log::info!("Sleep inhibition started: {}", 
            self.inhibitor.as_ref().unwrap().cookie());
        
        Ok(())
    }
    
    async fn stop_inhibition(&mut self) -> Result<()> {
        if let Some(inhibitor) = self.inhibitor.take() {
            log::info!("Sleep inhibition stopped");
            // inhibitor dropped, FD closed automatically
        }
        Ok(())
    }
}
```

## Configuration System

### Config File Structure

```yaml
# /etc/rouser/config.yaml

daemon:
  name: "rouser"
  update_interval: 5s
  log_level: info

thresholds:
  cpu_usage: 80.0        # Percentage (0-100)
  gpu_usage: 90.0        # Percentage (0-100)
  network_io: 100.0      # Mbps
  disk_activity: 50.0    # MB/s

timing:
  duration_threshold: 30  # Seconds metric must stay above threshold
  idle_duration: 60       # Seconds all metrics must stay below threshold

inhibition:
  what: "sleep,hibernate,shutdown"
  mode: "block"
```

### Config Loading

```rust
#[derive(Deserialize, Debug, Clone)]
pub struct Config {
    pub daemon: DaemonConfig,
    pub thresholds: Thresholds,
    pub timing: TimingConfig,
    pub inhibition: InhibitionConfig,
}

impl Config {
    pub fn load(path: &str) -> Result<Self> {
        let content = fs::read_to_string(path)?;
        let config: Config = serde_yaml::from_str(&content)?;
        Ok(config)
    }
    
    pub async fn reload(&mut self, path: &str) -> Result<()> {
        *self = Self::load(path)?;
        log::info!("Configuration reloaded");
        Ok(())
    }
}
```

## Error Handling Strategy

### Error Types

```rust
#[derive(Error, Debug)]
pub enum RouserError {
    #[error("Metric collection failed: {0}")]
    MetricCollection(#[from] MetricError),
    
    #[error("D-Bus error: {0}")]
    Dbus(#[from] zbus::Error),
    
    #[error("Configuration error: {0}")]
    Config(#[from] ConfigError),
    
    #[error("Permission denied: {0}")]
    PermissionDenied(String),
    
    #[error("IO error: {0}")]
    Io(#[from] io::Error),
}
```

### Error Recovery

```rust
impl Daemon {
    async fn run_with_recovery(&mut self) -> Result<()> {
        loop {
            match self.run_once().await {
                Ok(()) => {}
                Err(RouserError::MetricCollection(e)) => {
                    log::error!("Metric collection failed, retrying: {}", e);
                    tokio::time::sleep(Duration::from_secs(1)).await;
                    continue;
                }
                Err(RouserError::Dbus(e)) => {
                    log::error!("D-Bus error: {}", e);
                    // Could be temporary, retry after delay
                    tokio::time::sleep(Duration::from_secs(5)).await;
                    continue;
                }
                Err(e) => {
                    log::error!("Fatal error: {}", e);
                    return Err(e);
                }
            }
        }
    }
}
```

## Logging Strategy

### Log Levels

- `ERROR`: Fatal errors, permission denied
- `WARN`: Recoverable errors, configuration issues
- `INFO`: State changes (inhibit start/stop), config reload
- `DEBUG`: Metric values, detailed operation info

### Log Format

```rust
// Structured logging with metadata
log::info!(
    target: "rouser",
    "sleep_inhibited",
    cookie = %inhibitor_cookie,
    what = %what,
    metrics = ?metrics
);
```

## Resource Management

### File Descriptor Management

- Use RAII pattern with `Drop` trait
- Wrap D-Bus file descriptor in `File` struct
- Automatic cleanup on daemon shutdown

### Memory Management

- Bounded metric buffers (last N samples)
- No long-term metric storage
- Configuration loaded once, reloaded on SIGHUP

### CPU Efficiency

- Polling interval configurable (default 5s)
- No busy-waiting
- Efficient `/proc` parsing

## Security Considerations

### Permissions

- Requires read access to `/proc` (usually available)
- Requires D-Bus system bus access
- Add user to `login` group or run as root

### Configuration Security

- Config file should be readable only by root
- Validate all configuration values
- Sanitize description strings

### Error Handling

- Don't leak sensitive information in errors
- Log errors appropriately
- Graceful degradation on partial failures

## Testing Strategy

### Unit Tests

```rust
#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_threshold_evaluation() {
        let thresholds = Thresholds {
            cpu_usage: 80.0,
            gpu_usage: 90.0,
            network_io: 100.0,
            disk_activity: 50.0,
        };
        
        let metrics = SystemMetrics {
            cpu_usage: 85.0,
            gpu_usage: 70.0,
            network_io: 50.0,
            disk_activity: 25.0,
        };
        
        assert!(metrics.exceeds_thresholds(&thresholds));
        assert_eq!(metrics.exceeding_metric(), Some("cpu_usage"));
    }
    
    #[test]
    fn test_hysteresis_logic() {
        // Test that brief spikes don't trigger inhibition
        // Test that sustained activity triggers inhibition
    }
}
```

### Integration Tests

```rust
#[tokio::test]
async fn test_inhibitor_lifecycle() {
    let inhibitor = SleepInhibitor::new("sleep", "Test").await.unwrap();
    
    // Verify inhibitor is active
    let inhibitors = list_inhibitors("sleep").await.unwrap();
    assert!(inhibitors.iter().any(|i| i.cookie == inhibitor.cookie()));
    
    // Drop inhibitor
    drop(inhibitor);
    
    // Verify inhibitor is released
    let inhibitors = list_inhibitors("sleep").await.unwrap();
    assert!(!inhibitors.iter().any(|i| i.cookie == inhibitor.cookie()));
}
```

## Performance Considerations

### Time Complexity

- Metric collection: O(n) where n = number of cores/interfaces
- Threshold evaluation: O(1) - constant number of metrics
- D-Bus call: O(1) - single method call

### Space Complexity

- Metric storage: O(1) - fixed number of metrics
- History buffers: O(k) where k = configured buffer size
- Configuration: O(1) - single config object

### Optimization Opportunities

1. **Batch metric collection**: Read all `/proc` files in parallel
2. **Caching**: Cache metric values between checks
3. **Adaptive polling**: Increase interval when idle
4. **Incremental updates**: Only read changed `/proc` entries

## Deployment

### Systemd Service

```ini
# /etc/systemd/system/rouser.service
[Unit]
Description=Rouser Sleep Inhibition Daemon
After=network.target
Wants=network.target

[Service]
Type=simple
ExecStart=/usr/bin/rouser --config /etc/rouser/config.yaml
Restart=always
RestartSec=5
User=root
Group=root

# Security hardening
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=/var/log/rouser

[Install]
WantedBy=multi-user.target
```

### Installation Steps

```bash
# 1. Build and install binary
cargo build --release
sudo cp target/release/rouser /usr/bin/rouser

# 2. Create config directory
sudo mkdir -p /etc/rouser
sudo cp config.yaml /etc/rouser/config.yaml

# 3. Create log directory
sudo mkdir -p /var/log/rouser
sudo chown root:root /var/log/rouser

# 4. Enable and start service
sudo systemctl daemon-reload
sudo systemctl enable rouser
sudo systemctl start rouser

# 5. Check status
sudo systemctl status rouser
```

## Monitoring

### Metrics Export

```rust
// Export Prometheus metrics
pub async fn export_metrics() -> Result<String> {
    let metrics = self.collector.collect_metrics().await?;
    
    format!(
        "# HELP rouser_cpu_usage Current CPU usage percentage\n\
         # TYPE rouser_cpu_usage gauge\n\
         rouser_cpu_usage {}\n\
         # HELP rouser_inhibitor_active Whether sleep is inhibited\n\
         # TYPE rouser_inhibitor_active gauge\n\
         rouser_inhibitor_active {}\n",
        metrics.cpu_usage,
        if self.inhibitor.is_some() { 1.0 } else { 0.0 }
    )
}
```

### Health Check Endpoint

```rust
#[tokio::main]
async fn main() {
    let daemon = Daemon::new(config).await.unwrap();
    
    // Start HTTP server for health checks
    let health_server = tokio::spawn(async move {
        // ... health check implementation
    });
    
    daemon.run().await.unwrap();
}
```

## Future Enhancements

1. **GPU support**: Add support for AMD/Intel GPUs
2. **Custom metrics**: Allow user-defined metric sources
3. **Web UI**: Dashboard for monitoring and configuration
4. **Notification**: Alert when sleep is inhibited
5. **Multi-instance**: Support multiple inhibition contexts
6. **Machine learning**: Adaptive threshold adjustment

## References

- [systemd D-Bus API](https://www.freedesktop.org/software/systemd/man/org.freedesktop.login1.html)
- [zbus Documentation](https://docs.rs/zbus/)
- [Linux /proc filesystem](https://www.kernel.org/doc/Documentation/filesystems/proc.txt)
- [Rust Best Practices](https://rust-lang.github.io/api-guidelines/)
