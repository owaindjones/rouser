# Configuration Reference

## Overview

Rouser uses a YAML configuration file to define thresholds, timing parameters, and daemon behavior. This document describes all available configuration options.

## Configuration File

**Default Location**: `/etc/rouser/config.yaml`

**Command Line Override**: `rouser --config /path/to/config.yaml`

## Complete Configuration Example

```yaml
daemon:
  name: "rouser"
  update_interval: 5s
  log_level: info

thresholds:
  cpu_usage: 80.0
  gpu_usage: 90.0
  network_io: 100.0
  disk_activity: 50.0

timing:
  duration_threshold: 30s
  idle_duration: 60s

inhibition:
  what: "sleep,hibernate,shutdown"
  mode: "block"
```

## Threshold Configuration

### CPU Usage Threshold

```yaml
thresholds:
  cpu_usage: 80.0
```

- **Valid Range**: 0.0 - 100.0
- **Default**: 80.0
- **Description**: Aggregate CPU usage across all cores

### GPU Usage Threshold

```yaml
thresholds:
  gpu_usage: 90.0
```

- **Valid Range**: 0.0 - 100.0
- **Default**: 90.0
- **Requirements**: nvidia-smi or /sys/class/drm support

### Network I/O Threshold

```yaml
thresholds:
  network_io: 100.0
```

- **Valid Range**: 0.0 - infinity
- **Default**: 100.0 Mbps
- **Description**: Network throughput threshold

### Disk Activity Threshold

```yaml
thresholds:
  disk_activity: 50.0
```

- **Valid Range**: 0.0 - infinity
- **Default**: 50.0 MB/s
- **Description**: Disk read/write throughput

## Timing Configuration

### Duration Threshold

```yaml
timing:
  duration_threshold: 30s
```

- **Valid Range**: 0s - infinity
- **Default**: 30s
- **Purpose**: Prevents brief spikes from triggering inhibition

### Idle Duration

```yaml
timing:
  idle_duration: 60s
```

- **Valid Range**: 0s - infinity
- **Default**: 60s
- **Purpose**: Hysteresis to prevent rapid inhibit/release cycling

## D-Bus Inhibition Configuration

### What to Inhibit

```yaml
inhibition:
  what: "sleep,hibernate,shutdown"
```

- **sleep**: Suspend-to-RAM
- **hibernate**: Suspend-to-disk
- **shutdown**: Shutdown or reboot
- **idle**: Idle operations

### Inhibition Mode

```yaml
inhibition:
  mode: "block"
```

- **block**: Completely block the operation (default)
- **delay**: Delay the operation for a short period
- **interact**: Require user interaction before proceeding

## Daemon Configuration

### Update Interval

```yaml
daemon:
  update_interval: 5s
```

- **Valid Range**: 1s - 60s
- **Default**: 5s
- **Trade-offs**: Shorter = more responsive, higher CPU usage

### Log Level

```yaml
daemon:
  log_level: info
```

- **Valid Values**: debug, info, warn, error

## Logging Configuration

### Log File

```yaml
logging:
  file: "/var/log/rouser/rouser.log"
```

- **Options**: File path, stdout, stderr

### Log Rotation

```yaml
logging:
  rotation:
    max_size_mb: 10
    max_files: 5
    compress: true
```

### Log Format

```yaml
logging:
  format: "json"
```

- **Valid Values**: text, json

## Security Configuration

```yaml
security:
  user: "root"
  group: "root"
  drop_privileges: false
```

**Note**: Root privileges required for D-Bus system bus access

## Performance Tuning

### Metric Samples

```yaml
performance:
  max_metric_samples: 1000
```

- **Valid Range**: 100 - 10000
- **Default**: 1000

## Environment Variables

```bash
export ROUSER_CPU_THRESHOLD=75
export ROUSER_LOG_LEVEL=debug
rouser
```

## Best Practices

1. Start with conservative thresholds
2. Monitor and adjust based on usage patterns
3. Test configuration before production deployment
4. Use longer timing values initially to avoid false positives

## References

- [systemd D-Bus API](https://www.freedesktop.org/software/systemd/man/org.freedesktop.login1.html)
