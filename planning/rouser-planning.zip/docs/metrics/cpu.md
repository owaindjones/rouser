# CPU Metrics

## Overview

The `rouser` daemon collects CPU usage metrics by reading data from the `/proc/stat` file. This provides aggregate CPU usage across all processor cores on the system.

## Metric Details

### Primary Metric

| Metric | Type | Unit | Description |
|--------|------|------|-------------|
| `cpu_usage` | Percentage | 0.0 - 100.0 | Aggregate CPU usage across all cores |

## Data Source: `/proc/stat`

### File Format

The `/proc/stat` file contains system-wide CPU statistics in a specific text format. Here's a sample excerpt:

```
cpu  234567 12345 2345678 789012345 123456 1234 567 8901 0 0
cpu0 23456 1234 234567 789012 12345 123 56 789 0 0
cpu1 23456 1234 234567 789012 12345 123 56 789 0 0
...
```

### Field Descriptions

#### System-wide CPU line (first line starting with `cpu`)

| Field | Name | Description |
|-------|------|-------------|
| 1 | `user` | Normal processes executing in user mode (jiffies) |
| 2 | `nice` | Niced processes executing in user mode (jiffies) |
| 3 | `system` | Processes executing in kernel mode (jiffies) |
| 4 | `idle` | Twiddling thumbs (jiffies) |
| 5 | `iowait` | Waiting for I/O to complete (jiffies) |
| 6 | `irq` | Servicing interrupts (jiffies) |
| 7 | `softirq` | Servicing softirqs (jiffies) |
| 8 | `steal` | Stolen time in virtual machines (jiffies) |
| 9 | `guest` | Time spent running a virtual CPU for guest OS (jiffies) |
| 10 | `guest_idle` | Time spent running a nice guest (jiffies) |

#### Per-core lines (lines starting with `cpu0`, `cpu1`, etc.)

Same field structure as system-wide CPU line, but for individual CPU cores.

### Calculation of CPU Usage

To calculate CPU usage percentage, we need to:

1. **Read initial values** at time `t1`
2. **Wait for interval** (configurable, default 5 seconds)
3. **Read final values** at time `t2`
4. **Calculate differences** between t1 and t2
5. **Compute percentage** based on idle vs non-idle time

#### Formula

```rust
// Total time is sum of all CPU states
total_time = user + nice + system + idle + iowait + irq + softirq + steal + guest + guest_idle

// Non-idle time (time spent doing work)
non_idle_time = user + nice + system + iowait + irq + softirq + steal + guest

// CPU usage percentage
cpu_usage = ((non_idle_time / total_time) * 100.0)
```

### Implementation Approach

#### Two-Poll Method (Recommended)

```rust
pub struct CpuCollector {
    last_user: u64,
    last_system: u64,
    last_idle: u64,
    last_other: u64,
    last_read: SystemTime,
}

impl CpuCollector {
    pub async fn collect_cpu_usage(&self) -> Result<f64> {
        let cpu_stat = self.read_cpu_stat().await?;
        
        // Calculate differences since last read
        let user_delta = cpu_stat.user - self.last_user;
        let system_delta = cpu_stat.system - self.last_system;
        let idle_delta = cpu_stat.idle - self.last_idle;
        let other_delta = cpu_stat.other - self.last_other;
        
        let total_delta = user_delta + system_delta + idle_delta + other_delta;
        let non_idle_delta = user_delta + system_delta + other_delta;
        
        // Calculate usage percentage
        let usage = if total_delta > 0 {
            (non_idle_delta as f64 / total_delta as f64) * 100.0
        } else {
            0.0
        };
        
        // Update last values
        self.last_user = cpu_stat.user;
        self.last_system = cpu_stat.system;
        self.last_idle = cpu_stat.idle;
        self.last_other = cpu_stat.other;
        
        Ok(usage)
    }
}
```

#### Per-Core Aggregation

For per-core aggregation, we can either:

1. **Use system-wide `cpu` line** (simplest, recommended)
2. **Calculate per-core and average** (more granular)

```rust
// Option 1: Use system-wide line (recommended)
fn read_cpu_stat() -> Result<CpuStats> {
    let content = fs::read_to_string("/proc/stat")?;
    let first_line = content.lines().next().unwrap();
    let fields: Vec<u64> = first_line.split_whitespace()
        .skip(1) // Skip "cpu" prefix
        .map(|s| s.parse().unwrap_or(0))
        .collect();
    
    Ok(CpuStats {
        user: fields[0],
        nice: fields[1],
        system: fields[2],
        idle: fields[3],
        iowait: fields[4],
        irq: fields[5],
        softirq: fields[6],
        steal: fields[7],
        guest: fields[8],
        guest_idle: fields[9],
    })
}
```

### Edge Cases and Considerations

#### 1. **First Sample**

On first read, we can't calculate usage (no baseline). Solution:

```rust
// First read: initialize values, return no usage
// Second read onwards: calculate usage from deltas
```

#### 2. **Jiffies Overflow**

On long-running systems, jiffies can overflow. Solution:

- Use `u64` for jiffies (can run ~580 years before overflow)
- Handle wrap-around by detecting negative deltas

#### 3. **Clock Ticks (Jiffies)**

On Linux, clock frequency is typically 100 Hz (100 jiffies/second), but can vary:

```rust
// Check clock ticks per second (usually 100)
let clk_tck = sysconf(_SC_CLK_TCK).unwrap();
// Default on most systems: 100
```

#### 4. **Multi-Core Systems**

For aggregate usage across all cores:

- Use the system-wide `cpu` line (recommended)
- Alternatively, average per-core usage (more accurate for skewed workloads)

### Rust Implementation Example

```rust
use std::fs;
use std::time::{Duration, SystemTime};

#[derive(Debug, Clone, Default)]
pub struct CpuStats {
    pub user: u64,
    pub nice: u64,
    pub system: u64,
    pub idle: u64,
    pub iowait: u64,
    pub irq: u64,
    pub softirq: u64,
    pub steal: u64,
    pub guest: u64,
    pub guest_idle: u64,
}

pub struct CpuCollector {
    last_stats: Option<CpuStats>,
    last_time: Option<SystemTime>,
}

impl CpuCollector {
    pub fn new() -> Self {
        Self {
            last_stats: None,
            last_time: None,
        }
    }
    
    pub async fn collect_cpu_usage(&mut self) -> Result<f64, CpuError> {
        let stats = self.read_stats().await?;
        let now = SystemTime::now();
        
        match (self.last_stats, self.last_time) {
            (Some(prev_stats), Some(prev_time)) => {
                // Calculate delta
                let user_delta = stats.user - prev_stats.user;
                let system_delta = stats.system - prev_stats.system;
                let idle_delta = stats.idle - prev_stats.idle;
                let other_delta = (stats.iowait + stats.irq + stats.softirq + 
                                  stats.steal + stats.guest) -
                                 (prev_stats.iowait + prev_stats.irq + 
                                  prev_stats.softirq + prev_stats.steal + 
                                  prev_stats.guest);
                
                let total_delta = user_delta + system_delta + idle_delta + other_delta;
                let non_idle_delta = user_delta + system_delta + other_delta;
                
                let usage = if total_delta > 0 {
                    ((non_idle_delta as f64) / (total_delta as f64)) * 100.0
                } else {
                    0.0
                };
                
                self.last_stats = Some(stats);
                self.last_time = Some(now);
                
                Ok(usage)
            }
            _ => {
                // First sample - initialize and return 0
                self.last_stats = Some(stats);
                self.last_time = Some(now);
                Ok(0.0)
            }
        }
    }
    
    fn read_stats(&self) -> Result<CpuStats, CpuError> {
        let content = fs::read_to_string("/proc/stat")
            .map_err(|e| CpuError::IoError(e.to_string()))?;
        
        let first_line = content.lines()
            .find(|l| l.starts_with("cpu "))
            .ok_or(CpuError::InvalidFormat)?;
        
        let fields: Vec<u64> = first_line.split_whitespace()
            .skip(1)
            .map(|s| s.parse().unwrap_or(0))
            .collect();
        
        if fields.len() < 10 {
            return Err(CpuError::InvalidFormat);
        }
        
        Ok(CpuStats {
            user: fields[0],
            nice: fields[1],
            system: fields[2],
            idle: fields[3],
            iowait: fields[4],
            irq: fields[5],
            softirq: fields[6],
            steal: fields[7],
            guest: fields[8],
            guest_idle: fields[9],
        })
    }
}

#[derive(Debug)]
pub enum CpuError {
    IoError(String),
    InvalidFormat,
}
```

### Alternative Sources

#### `/proc/loadavg`

Alternative source for load average (1, 5, 15 minute averages):

```
cat /proc/loadavg
# Output: 0.25 0.18 0.15 3/456 12345
```

**Pros**:
- Simpler to parse
- No need for two-sample calculation

**Cons**:
- Provides time-averaged load, not instantaneous usage
- Load average includes processes in uninterruptible sleep

#### `sysinfo` Crate

For simpler implementation, consider using the `sysinfo` crate:

```toml
[dependencies]
sysinfo = "0.30"
```

```rust
use sysinfo::{System, SystemExt};

let mut system = System::new_all();
system.refresh_cpu_usage();
let cpu_usage = system.get_cpu_usage();
```

### Performance Considerations

- **File I/O**: Reading `/proc/stat` is very fast (no disk I/O, all in memory)
- **CPU usage**: Minimal overhead from parsing
- **Polling interval**: Default 5s provides good balance between responsiveness and efficiency
- **No external dependencies**: Using standard `/proc` filesystem

### Testing

#### Unit Test Example

```rust
#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_parse_cpu_line() {
        let line = "cpu  100 20 300 4000 50 60 70 80 90 100";
        let stats = parse_cpu_line(line).unwrap();
        
        assert_eq!(stats.user, 100);
        assert_eq!(stats.system, 300);
        assert_eq!(stats.idle, 4000);
    }
    
    #[test]
    fn test_cpu_usage_calculation() {
        // Test that 50% usage gives correct calculation
        let stats1 = CpuStats {
            user: 100, nice: 10, system: 100, idle: 1000,
            iowait: 10, irq: 10, softirq: 10, steal: 0, guest: 0, guest_idle: 0,
        };
        
        let stats2 = CpuStats {
            user: 200, nice: 20, system: 200, idle: 2000,
            iowait: 20, irq: 20, softirq: 20, steal: 0, guest: 0, guest_idle: 0,
        };
        
        // Should calculate 50% usage
        assert!((calculate_usage(&stats1, &stats2) - 50.0).abs() < 0.01);
    }
}
```

### References

- [Linux /proc/stat Documentation](https://www.kernel.org/doc/Documentation/filesystems/proc.txt)
- [proc(5) man page](https://man7.org/linux/man-pages/man5/proc.5.html)
- [Rust std::fs Documentation](https://doc.rust-lang.org/std/fs/index.html)

## Summary

CPU metrics are collected from `/proc/stat`, which provides system-wide and per-core CPU usage statistics. The primary metric is aggregate CPU usage percentage calculated from the difference in idle vs non-idle time between two sampling intervals. This approach is efficient, requires no external dependencies, and works on all Linux systems.
