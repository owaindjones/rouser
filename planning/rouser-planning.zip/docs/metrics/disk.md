# Disk I/O Metrics

## Overview

The `rouser` daemon collects disk I/O metrics by reading from the `/proc/diskstats` file. This provides disk read/write activity and throughput statistics across all block devices on the system.

## Metric Details

### Primary Metric

| Metric | Type | Unit | Description |
|--------|------|------|-------------|
| `disk_activity` | Throughput | KB/s or MB/s | Total disk I/O throughput (read + write) |

**Alternative representations**:
| Metric | Type | Unit | Description |
|--------|------|------|-------------|
| `disk_read` | Throughput | KB/s or MB/s | Disk read throughput |
| `disk_write` | Throughput | KB/s or MB/s | Disk write throughput |
| `disk_sectors_read` | Count | Sectors/second | Sectors read per second |
| `disk_sectors_write` | Count | Sectors/second | Sectors written per second |

### Derived Metrics

| Metric | Type | Unit | Description |
|--------|------|------|-------------|
| `disk_ops` | IOPS | Operations/second | Total I/O operations per second |

## Data Source: `/proc/diskstats`

### File Format

The `/proc/diskstats` file contains block device statistics in the following format:

```
   8:0    sda 8 4200000 64000000 40000000 1000000 3000000 128000000 60000000 0 0 150000000 172000000 0 0
   8:1    sda1 1 100000 1280000 400000 0 0 0 0 0 0 1200000 1400000 0 0
   8:2    sda2 5 9000000 80000000 30000000 500000 2000000 100000000 50000000 0 0 100000000 120000000 0 0
```

Or in newer kernels with more fields:

```
   8:0    sda 8 4200000 64000000 40000000 1000000 3000000 128000000 60000000 0 0 150000000 172000000 0 0 0 0
```

### Field Descriptions

| Field | Description |
|-------|-------------|
| 0 | Major device number |
| 1 | Minor device number |
| 2 | Device name (e.g., `sda`, `nvme0n1`) |
| 3 | `rd_ios` | Number of reads completed successfully |
| 4 | `rd_ticks` | Merged reads |
| 5 | `rd_sectors` | Sectors read (in sectors, 512 bytes each) |
| 6 | `rd_ticks_time` | Time spent reading (milliseconds) |
| 7 | `wr_ios` | Number of writes completed |
| 8 | `wr_ticks` | Merged writes |
| 9 | `wr_sectors` | Sectors written (in sectors) |
| 10 | `wr_ticks_time` | Time spent writing (milliseconds) |
| 11 | `in_flight` | Current I/O requests in flight |
| 12 | `io_ticks` | Total time spent doing I/O (milliseconds) |
| 13 | `weighted_io_time` | Weighted time spent doing I/O |
| 14+ | Additional fields in newer kernels |

### Parsing Algorithm

```rust
#[derive(Debug, Clone, Default)]
pub struct DiskStats {
    pub name: String,
    pub rd_ios: u64,
    pub rd_sectors: u64,
    pub rd_ticks: u64,
    pub rd_ticks_time: u64,
    pub wr_ios: u64,
    pub wr_sectors: u64,
    pub wr_ticks: u64,
    pub wr_ticks_time: u64,
    pub in_flight: u64,
    pub io_ticks: u64,
    pub weighted_io_time: u64,
}

fn parse_diskstats_line(line: &str) -> Result<DiskStats> {
    let parts: Vec<&str> = line.split_whitespace().collect();
    
    if parts.len() < 14 {
        return Err(DiskError::InvalidFormat);
    }
    
    Ok(DiskStats {
        name: parts[2].to_string(),
        rd_ios: parts[3].parse()?,
        rd_sectors: parts[5].parse()?,
        rd_ticks: parts[4].parse()?,
        rd_ticks_time: parts[6].parse()?,
        wr_ios: parts[7].parse()?,
        wr_sectors: parts[9].parse()?,
        wr_ticks: parts[8].parse()?,
        wr_ticks_time: parts[10].parse()?,
        in_flight: parts[11].parse()?,
        io_ticks: parts[12].parse()?,
        weighted_io_time: parts[13].parse()?,
    })
}
```

## Throughput Calculation

### Two-Sample Method

To calculate disk throughput (MB/s or KB/s), we use a two-sample approach:

```rust
pub struct DiskCollector {
    last_stats: HashMap<String, DiskStats>,
    last_time: SystemTime,
}

impl DiskCollector {
    pub async fn collect_disk_activity(&mut self) -> Result<DiskMetrics> {
        let current_stats = self.read_diskstats().await?;
        let current_time = SystemTime::now();
        
        let delta = current_time.duration_since(self.last_time)
            .unwrap_or(Duration::from_secs(0));
        
        let mut total_read_bytes = 0u64;
        let mut total_written_bytes = 0u64;
        
        for (name, new_stats) in &current_stats {
            if let Some(old_stats) = self.last_stats.get(name) {
                // Calculate bytes difference (1 sector = 512 bytes)
                let read_bytes = (new_stats.rd_sectors.saturating_sub(old_stats.rd_sectors)) 
                    * 512;
                let written_bytes = (new_stats.wr_sectors.saturating_sub(old_stats.wr_sectors)) 
                    * 512;
                
                total_read_bytes = total_read_bytes.saturating_add(read_bytes);
                total_written_bytes = total_written_bytes.saturating_add(written_bytes);
            }
        }
        
        // Calculate bytes per second
        let delta_secs = delta.as_secs_f64();
        if delta_secs < 0.001 {
            return Ok(DiskMetrics::default());
        }
        
        let read_bytes_per_sec = (total_read_bytes as f64) / delta_secs;
        let written_bytes_per_sec = (total_written_bytes as f64) / delta_secs;
        
        // Convert to KB/s or MB/s
        let read_kb_s = read_bytes_per_sec / 1024.0;
        let written_kb_s = written_bytes_per_sec / 1024.0;
        let read_mb_s = read_kb_s / 1024.0;
        let written_mb_s = written_kb_s / 1024.0;
        
        // Update last stats
        self.last_stats = current_stats;
        self.last_time = current_time;
        
        Ok(DiskMetrics {
            read_kb_s,
            write_kb_s,
            read_mb_s,
            write_mb_s,
            total_kb_s: read_kb_s + written_kb_s,
            total_mb_s: read_mb_s + written_mb_s,
        })
    }
}
```

### Complete Implementation

```rust
use std::collections::HashMap;
use std::fs;
use std::time::{Duration, SystemTime};

#[derive(Debug, Clone, Default)]
pub struct DiskStats {
    pub name: String,
    pub rd_sectors: u64,
    pub wr_sectors: u64,
    pub rd_ios: u64,
    pub wr_ios: u64,
}

#[derive(Debug, Clone, Default)]
pub struct DiskMetrics {
    pub read_kb_s: f64,
    pub write_kb_s: f64,
    pub read_mb_s: f64,
    pub write_mb_s: f64,
    pub total_kb_s: f64,
    pub total_mb_s: f64,
}

pub struct DiskCollector {
    last_stats: HashMap<String, DiskStats>,
    last_time: SystemTime,
    include_devices: Option<Vec<String>>,
    exclude_devices: Vec<String>,
}

impl DiskCollector {
    pub fn new() -> Self {
        Self {
            last_stats: HashMap::new(),
            last_time: SystemTime::UNIX_EPOCH,
            include_devices: None,
            exclude_devices: vec![],
        }
    }
    
    pub fn with_excluded_devices(mut self, devices: Vec<String>) -> Self {
        self.exclude_devices = devices;
        self
    }
    
    pub async fn collect_disk_activity(&mut self) -> Result<DiskMetrics> {
        let current_stats = self.read_diskstats().await?;
        let current_time = SystemTime::now();
        
        let delta = match current_time.duration_since(self.last_time) {
            Ok(d) => d,
            Err(_) => Duration::from_secs(1),
        };
        
        let delta_secs = delta.as_secs_f64();
        if delta_secs < 0.001 {
            return Ok(DiskMetrics::default());
        }
        
        let mut total_read_sectors = 0u64;
        let mut total_written_sectors = 0u64;
        
        for (name, new_stats) in &current_stats {
            // Skip excluded devices
            if self.exclude_devices.contains(name) {
                continue;
            }
            
            // Apply include filter if set
            if let Some(ref include) = self.include_devices {
                if !include.contains(name) {
                    continue;
                }
            }
            
            // Skip virtual devices (loopback, cdrom, etc.)
            if Self::is_virtual_device(name) {
                continue;
            }
            
            if let Some(old_stats) = self.last_stats.get(name) {
                let read_sectors_delta = new_stats.rd_sectors.saturating_sub(old_stats.rd_sectors);
                let written_sectors_delta = new_stats.wr_sectors.saturating_sub(old_stats.wr_sectors);
                
                total_read_sectors = total_read_sectors.saturating_add(read_sectors_delta);
                total_written_sectors = total_written_sectors.saturating_add(written_sectors_delta);
            }
        }
        
        // Convert sectors to bytes (1 sector = 512 bytes)
        let total_read_bytes = total_read_sectors * 512;
        let total_written_bytes = total_written_sectors * 512;
        
        // Calculate bytes per second
        let read_bytes_per_sec = (total_read_bytes as f64) / delta_secs;
        let written_bytes_per_sec = (total_written_bytes as f64) / delta_secs;
        
        // Convert to KB/s or MB/s
        let read_kb_s = read_bytes_per_sec / 1024.0;
        let written_kb_s = written_bytes_per_sec / 1024.0;
        let read_mb_s = read_kb_s / 1024.0;
        let written_mb_s = written_kb_s / 1024.0;
        
        // Update last stats
        self.last_stats = current_stats;
        self.last_time = current_time;
        
        Ok(DiskMetrics {
            read_kb_s,
            write_kb_s,
            read_mb_s,
            write_mb_s,
            total_kb_s: read_kb_s + written_kb_s,
            total_mb_s: read_mb_s + written_mb_s,
        })
    }
    
    fn read_diskstats(&self) -> Result<HashMap<String, DiskStats>> {
        let content = fs::read_to_string("/proc/diskstats")
            .map_err(|e| DiskError::IoError(e.to_string()))?;
        
        let mut stats = HashMap::new();
        
        for line in content.lines() {
            // Skip empty lines
            if line.trim().is_empty() {
                continue;
            }
            
            match Self::parse_diskstats_line(line) {
                Ok(stats_entry) => {
                    stats.insert(stats_entry.name.clone(), stats_entry);
                }
                Err(_) => {
                    // Skip malformed lines
                    continue;
                }
            }
        }
        
        Ok(stats)
    }
    
    fn parse_diskstats_line(line: &str) -> Result<DiskStats> {
        let parts: Vec<&str> = line.split_whitespace().collect();
        
        if parts.len() < 14 {
            return Err(DiskError::InvalidFormat);
        }
        
        Ok(DiskStats {
            name: parts[2].to_string(),
            rd_sectors: parts[5].parse()?,
            wr_sectors: parts[9].parse()?,
            rd_ios: parts[3].parse()?,
            wr_ios: parts[7].parse()?,
        })
    }
    
    fn is_virtual_device(name: &str) -> bool {
        // Common virtual device prefixes
        let virtual_prefixes = [
            "loop",   // Loop devices
            "fd",     // Floppy disks
            "sr",     // SCSI CD-ROM
            "vd",     // Virtual block devices (Xen)
            "xvd",    // Xen virtual block devices
            "ram",    // RAM disks
            "zd",     // ZFS disk images
            "nbd",    // Network block devices
            "dm-",    // Device mapper (LVM)
            "crcw",   // CRC writer
        ];
        
        virtual_prefixes.iter().any(|prefix| name.starts_with(prefix))
    }
}
```

## Configuration Options

### Device Filtering

```rust
// Exclude specific devices
let collector = DiskCollector::new()
    .with_excluded_devices(vec![
        "loop0".to_string(),
        "loop1".to_string(),
        "sr0".to_string(),
    ]);

// Only include specific devices
collector.include_devices = vec!["sda".to_string(), "nvme0n1".to_string()];
```

### Unit Configuration

```rust
// Available units
enum DiskUnit {
    BytesPerSec,
    KBPerSec,
    MBPerSec,
    GBytesPerSec,
}

// For configuration, default to MB/s
let threshold_mbps: f64 = 50.0; // 50 MB/s
```

## Edge Cases and Considerations

### 1. First Sample

On first read, we can't calculate throughput. Solution:

```rust
// First read: initialize values, return 0 throughput
// Second read onwards: calculate throughput from deltas
```

### 2. Sector Size Variations

Different devices may use different sector sizes (typically 512 bytes, but can be 4096 bytes for Advanced Format drives). The implementation assumes 512-byte sectors as per Linux kernel convention.

### 3. Device Name Changes

Device names can change (e.g., USB devices), but this is handled naturally:

- New devices: First sample initializes them
- Removed devices: Simply stop being included in calculations

### 4. Virtual Devices

Virtual devices (loopback, LVM, etc.) may have different characteristics. They can be filtered out:

```rust
// Skip virtual devices by default
// Loopback, CD-ROM, RAM disks, etc.
```

### 5. Read-Ahead and Caching

Linux uses disk cache aggressively, so short-term throughput may not reflect actual disk activity. Longer polling intervals (5-10s) provide better averages.

### 6. Polling Interval

Recommended polling intervals:

| Interval | Use Case |
|----------|----------|
| 1-2s | High-frequency monitoring |
| 3-5s | Default, balanced |
| 10s | Low-frequency, low-overhead |

Shorter intervals may miss brief bursts; longer intervals may average out peaks.

## Alternative Sources

### iostat (sysstat)

```bash
# Install sysstat
sudo apt install sysstat

# Get disk statistics
iostat -x 1 5

# Or with custom format
iostat -d -k 1 5
```

**Pros**: Rich statistics, includes I/O wait time
**Cons**: External dependency, slower than /proc/diskstats

### blktrace/blkparse

```bash
# Block layer tracing
blktrace -d /dev/sda -o - | blkparse -i -
```

**Pros**: Very detailed I/O trace data
**Cons**: Complex, requires kernel tracing support, not suitable for simple monitoring

### dmsetup (for LVM)

```bash
# Device mapper statistics
dmsetup stats --showstats
```

**Pros**: LVM-specific statistics
**Cons**: Only for device mapper devices, external dependency

## Performance Considerations

- **File I/O**: Reading `/proc/diskstats` is very fast (no disk I/O, all in memory)
- **Parsing**: Minimal overhead from string splitting and parsing
- **Memory**: O(n) where n is number of block devices (typically < 20)
- **CPU usage**: Negligible for typical polling intervals

## Testing

### Unit Test Example

```rust
#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_parse_diskstats_line() {
        let line = "   8:0    sda 8 4200000 64000000 40000000 1000000 3000000 128000000";
        let stats = parse_diskstats_line(line).unwrap();
        
        assert_eq!(stats.name, "sda");
        assert_eq!(stats.rd_sectors, 64_000_000);
        assert_eq!(stats.wr_sectors, 128_000_000);
    }
    
    #[test]
    fn test_is_virtual_device() {
        assert!(DiskCollector::is_virtual_device("loop0"));
        assert!(DiskCollector::is_virtual_device("sr0"));
        assert!(DiskCollector::is_virtual_device("dm-0"));
        assert!(!DiskCollector::is_virtual_device("sda"));
        assert!(!DiskCollector::is_virtual_device("nvme0n1"));
    }
}
```

## Configuration Reference

### Threshold Configuration

```yaml
thresholds:
  # Disk activity threshold in MB/s
  disk_activity: 50.0
  
  # Optional: separate read/write thresholds
  disk_read: 30.0   # MB/s read
  disk_write: 20.0  # MB/s write
```

### Device Filtering

```yaml
disk:
  # Devices to exclude from monitoring
  exclude:
    - loop0
    - loop1
    - sr0
    - fd0
    - fd1
  
  # Devices to include (if not set, monitor all except excluded)
  include:
    - sda
    - nvme0n1
```

## Summary

Disk I/O metrics are collected from `/proc/diskstats`, which provides comprehensive block device statistics. The primary metric is aggregate disk throughput calculated from the difference in read/write sectors between two sampling intervals. This approach:

- Requires no external dependencies
- Provides real-time disk activity data
- Supports multiple block devices
- Handles virtual devices appropriately
- Can filter devices via configuration

The implementation uses a two-sample approach to calculate bytes-per-second rates, which are then converted to KB/s or MB/s based on configuration preferences. By default, virtual devices (loopback, CD-ROM, etc.) are excluded to focus on physical storage activity.
