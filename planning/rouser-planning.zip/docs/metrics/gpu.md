# GPU Metrics

## Overview

The `rouser` daemon collects GPU usage metrics from multiple sources depending on the GPU hardware available on the system. Support includes NVIDIA (via `nvidia-smi`), AMD (via sysfs), and Intel integrated graphics.

## Metric Details

### Primary Metric

| Metric | Type | Unit | Description |
|--------|------|------|-------------|
| `gpu_usage` | Percentage | 0.0 - 100.0 | Aggregate GPU utilization |

## Data Sources

### 1. NVIDIA GPUs

**Primary Method**: `nvidia-smi` command-line tool

**Fallback**: `/proc/driver/nvidia/gpu/` (if available)

#### nvidia-smi Method

The `nvidia-smi` (NVIDIA System Management Interface) tool provides comprehensive GPU monitoring capabilities:

```bash
# Get GPU utilization percentage
nvidia-smi --query-gpu=utilization.gpu --format=csv,noheader,nounits

# Get detailed GPU info including memory usage
nvidia-smi --query-gpu=utilization.gpu,memory.used,memory.total --format=csv
```

**Sample Output**:
```
 85%
```

Or for multiple GPUs (one per line):
```
 75%
 90%
 45%
 60%
```

**Parsing JSON Output** (preferred for multiple GPUs):
```bash
nvidia-smi --query-gpu=utilization.gpu --format=csv,noheader
```

Or for structured data:
```bash
nvidia-smi --query-gpu=index,utilization.gpu,memory.used,memory.total --format=csv
```

**Sample JSON Output**:
```json
{
  "data": [
    {"index": "0", "utilization.gpu": "75"},
    {"index": "1", "utilization.gpu": "90"},
    {"index": "2", "utilization.gpu": "45"},
    {"index": "3", "utilization.gpu": "60"}
  ]
}
```

#### /proc/driver/nvidia Method

For systems where `nvidia-smi` is not available, the NVIDIA kernel driver exposes GPU stats via sysfs:

```
/sys/class/drm/card0/device/
```

This method is less common and requires specific driver configurations.

### 2. AMD GPUs

**Primary Method**: `/sys/class/drm/` sysfs interface

#### AMD GPU Metrics Location

```bash
# For AMD GPUs using amdgpu driver
/sys/class/drm/card0/device/gpu_busy_percent
/sys/class/drm/card0/device/uvm/gfx_busy_ms
/sys/class/drm/card0/device/uvm/compute_busy_ms
```

#### Reading AMD GPU Utilization

```bash
# GPU busy percentage
cat /sys/class/drm/card0/device/gpu_busy_percent

# For multi-GPU systems, iterate through available cards
for card in /sys/class/drm/card*/device/gpu_busy_percent; do
    card_name=$(basename $(dirname $(dirname $card)))
    usage=$(cat $card)
    echo "$card_name: $usage%"
done
```

**Alternative**: Using `radeontop` or `rocm-smi` for AMD ROCm GPUs:

```bash
# ROCm GPUs (data center/workstation)
rocm-smi --query-gpu Utilization-Gpu --showonly
```

### 3. Intel Integrated Graphics

**Primary Method**: `/sys/class/drm/` sysfs interface

#### Intel GPU Metrics Location

```bash
# For Intel i915 driver
/sys/class/drm/card0/device/uvm/render_busy_ms
/sys/class/drm/card0/device/uvm/compute_busy_ms
```

#### Reading Intel GPU Utilization

```bash
# Check for render engine activity
cat /sys/class/drm/card0/device/uvm/render_busy_ms

# Parse relative to total time for percentage
# (requires comparing against system uptime or another time source)
```

**Alternative**: Using `intel_gpu_top` (part of `intel-gpu-tools` package):

```bash
# Interactive GPU monitoring
sudo intel_gpu_top

# Query specific metrics
intel_gpu_top --json
```

### 4. General Purpose GPU Monitoring

**Fallback**: General hardware monitoring via `hwloc` or similar:

```bash
# Check for available GPU hardware
lspci | grep -E 'VGA|3D|Display'

# Check for CUDA-capable devices
nvidia-smi -L
```

## Implementation Strategy

### Multi-Source Detection and Fallback

The GPU collector should implement a priority-based detection system:

```rust
pub enum GpuSource {
    Nvsmi,     // NVIDIA nvidia-smi (highest priority)
    Amdgpu,    // AMD GPU via sysfs
    Intel,     // Intel i915 via sysfs
    Rocm,      // AMD ROCm
    Unknown,   // No supported GPU detected
}

pub struct GpuCollector {
    source: GpuSource,
    last_usage: Option<f64>,
}

impl GpuCollector {
    pub fn detect_source() -> Result<Self> {
        // Try NVIDIA first
        if Self::check_nvidia().await? {
            return Ok(Self {
                source: GpuSource::Nvsmi,
                last_usage: None,
            });
        }
        
        // Try AMD ROCm
        if Self::check_rocm().await? {
            return Ok(Self {
                source: GpuSource::Rocm,
                last_usage: None,
            });
        }
        
        // Try AMD GPU via sysfs
        if Self::check_amdgpu().await? {
            return Ok(Self {
                source: GpuSource::Amdgpu,
                last_usage: None,
            });
        }
        
        // Try Intel
        if Self::check_intel().await? {
            return Ok(Self {
                source: GpuSource::Intel,
                last_usage: None,
            });
        }
        
        Ok(Self {
            source: GpuSource::Unknown,
            last_usage: None,
        })
    }
}
```

### NVIDIA Implementation

```rust
use std::process::Command;
use std::thread;
use std::time::Duration;

pub struct NvGpuCollector {
    nvidia_smi_path: String,
}

impl NvGpuCollector {
    pub async fn collect_gpu_usage(&self) -> Result<f64, GpuError> {
        // Check if nvidia-smi is available
        let output = Command::new(&self.nvidia_smi_path)
            .args(&["--query-gpu=utilization.gpu", "--format=csv,noheader,nounits"])
            .output()
            .map_err(|e| GpuError::CommandFailed(e.to_string()))?;
        
        if !output.status.success() {
            return Err(GpuError::NvidiaSmiError(String::from_utf8_lossy(&output.stderr).to_string()));
        }
        
        // Parse output (one value per line for multi-GPU)
        let usage_string = String::from_utf8_lossy(&output.stdout);
        
        // Calculate average across all GPUs
        let total_usage: f64 = usage_string
            .lines()
            .filter(|line| !line.trim().is_empty())
            .map(|line| {
                line.trim().parse::<f64>()
                    .unwrap_or(0.0)
            })
            .sum();
        
        let num_gpus = usage_string.lines()
            .filter(|line| !line.trim().is_empty())
            .count();
        
        let average_usage = if num_gpus > 0 {
            total_usage / (num_gpus as f64)
        } else {
            0.0
        };
        
        Ok(average_usage)
    }
    
    fn check_nvidia() -> bool {
        Command::new("nvidia-smi")
            .arg("--query-gpu=index")
            .arg("--format=csv,noheader,nounits")
            .output()
            .map(|output| output.status.success())
            .unwrap_or(false)
    }
}
```

### AMD GPU Implementation (sysfs)

```rust
use std::fs;

pub struct AmdgpuCollector;

impl AmdgpuCollector {
    pub async fn collect_gpu_usage(&self) -> Result<f64, GpuError> {
        let mut total_usage = 0.0;
        let mut gpu_count = 0;
        
        // Iterate through all available GPUs
        for entry in fs::read_dir("/sys/class/drm")
            .map_err(|e| GpuError::IoError(e.to_string()))?
        {
            let entry = entry.map_err(|e| GpuError::IoError(e.to_string()))?;
            let path = entry.path();
            
            if path.ends_with("device") {
                let gpu_path = path.parent()
                    .ok_or_else(|| GpuError::InvalidPath(path.clone()))?;
                
                let busy_percent_path = gpu_path.join("device/gpu_busy_percent");
                
                if busy_percent_path.exists() {
                    let content = fs::read_to_string(&busy_percent_path)
                        .map_err(|e| GpuError::IoError(e.to_string()))?;
                    
                    let usage: f64 = content.trim()
                        .parse()
                        .unwrap_or(0.0);
                    
                    total_usage += usage;
                    gpu_count += 1;
                }
            }
        }
        
        let average_usage = if gpu_count > 0 {
            total_usage / (gpu_count as f64)
        } else {
            0.0
        };
        
        Ok(average_usage)
    }
}
```

### Intel GPU Implementation

```rust
use std::fs;
use std::time::{SystemTime, UNIX_EPOCH};

pub struct IntelGpuCollector;

impl IntelGpuCollector {
    pub async fn collect_gpu_usage(&self) -> Result<f64, GpuError> {
        // Intel GPUs use render_busy_ms and other time-based metrics
        // We need to compare against a baseline to calculate usage
        
        let busy_path = "/sys/class/drm/card0/device/uvm/render_busy_ms";
        
        if !fs::metadata(busy_path).is_ok() {
            // Try to find the correct card
            let cards = fs::read_dir("/sys/class/drm")?
                .filter_map(|e| e.ok())
                .filter(|e| e.path().to_string_lossy().contains("card"))
                .collect::<Vec<_>>();
            
            if cards.is_empty() {
                return Ok(0.0);
            }
            
            // For simplicity, use first available card
            // In production, enumerate all GPUs
            let card = &cards[0];
            let card_name = card.file_name().to_string_lossy();
            
            if !card_name.starts_with("card") {
                return Ok(0.0);
            }
            
            let busy_path = format!("/sys/class/drm/{}/device/uvm/render_busy_ms", card_name);
            return self.collect_from_path(&busy_path).await;
        }
        
        self.collect_from_path(busy_path).await
    }
    
    async fn collect_from_path(&self, busy_path: &str) -> Result<f64, GpuError> {
        let busy_ms = fs::read_to_string(busy_path)
            .map_err(|e| GpuError::IoError(e.to_string()))?;
        
        let busy_ms: f64 = busy_ms.trim()
            .parse()
            .unwrap_or(0.0);
        
        // Get total system uptime (in milliseconds)
        let uptime_ms = self.get_system_uptime_ms().await?;
        
        // Calculate usage as percentage of busy time vs total uptime
        let usage = if uptime_ms > 0.0 {
            (busy_ms / uptime_ms) * 100.0
        } else {
            0.0
        };
        
        Ok(usage)
    }
    
    async fn get_system_uptime_ms(&self) -> Result<f64, GpuError> {
        let content = fs::read_to_string("/proc/uptime")
            .map_err(|e| GpuError::IoError(e.to_string()))?;
        
        let uptime_seconds: f64 = content.split_whitespace()
            .next()
            .unwrap_or("0")
            .parse()
            .unwrap_or(0.0);
        
        Ok(uptime_seconds * 1000.0)
    }
}
```

### ROCm GPU Implementation

```rust
use std::process::Command;

pub struct RocmGpuCollector;

impl RocmGpuCollector {
    pub async fn collect_gpu_usage(&self) -> Result<f64, GpuError> {
        // Check if rocm-smi is available
        let output = Command::new("rocm-smi")
            .args(&["--query-gpu=Utilization-Gpu", "--showonly"])
            .output()
            .map_err(|e| GpuError::CommandFailed(e.to_string()))?;
        
        if !output.status.success() {
            return Err(GpuError::RocmSmiError(String::from_utf8_lossy(&output.stderr).to_string()));
        }
        
        // Parse output (one value per GPU)
        let usage_string = String::from_utf8_lossy(&output.stdout);
        
        // Calculate average across all GPUs
        let total_usage: f64 = usage_string
            .lines()
            .filter(|line| !line.trim().is_empty())
            .map(|line| {
                line.trim().parse::<f64>()
                    .unwrap_or(0.0)
            })
            .sum();
        
        let num_gpus = usage_string.lines()
            .filter(|line| !line.trim().is_empty())
            .count();
        
        let average_usage = if num_gpus > 0 {
            total_usage / (num_gpus as f64)
        } else {
            0.0
        };
        
        Ok(average_usage)
    }
}
```

## Unified GPU Collector

```rust
pub struct GpuCollector {
    source: Option<GpuSource>,
    last_usage: Option<f64>,
    update_interval: Duration,
}

#[derive(Debug, Clone)]
pub enum GpuSource {
    Nvsmi,
    Amdgpu,
    Intel,
    Rocm,
}

impl GpuCollector {
    pub fn new() -> Result<Self> {
        let source = Self::detect_gpu_source()?;
        
        Ok(Self {
            source: Some(source),
            last_usage: None,
            update_interval: Duration::from_secs(5),
        })
    }
    
    fn detect_gpu_source() -> Result<GpuSource> {
        // Priority order: NVIDIA > ROCm > AMD > Intel
        
        if Self::check_nvidia() {
            return Ok(GpuSource::Nvsmi);
        }
        
        if Self::check_rocm() {
            return Ok(GpuSource::Rocm);
        }
        
        if Self::check_amdgpu() {
            return Ok(GpuSource::Amdgpu);
        }
        
        if Self::check_intel() {
            return Ok(GpuSource::Intel);
        }
        
        Err(GpuError::NoGpuDetected)
    }
    
    pub async fn collect_gpu_usage(&self) -> Result<f64, GpuError> {
        match &self.source {
            Some(GpuSource::Nvsmi) => {
                let collector = NvGpuCollector::new()?;
                collector.collect_gpu_usage().await
            }
            Some(GpuSource::Rocm) => {
                let collector = RocmGpuCollector;
                collector.collect_gpu_usage().await
            }
            Some(GpuSource::Amdgpu) => {
                let collector = AmdgpuCollector;
                collector.collect_gpu_usage().await
            }
            Some(GpuSource::Intel) => {
                let collector = IntelGpuCollector;
                collector.collect_gpu_usage().await
            }
            None => Err(GpuError::NoGpuDetected),
        }
    }
    
    fn check_nvidia() -> bool {
        Command::new("nvidia-smi")
            .arg("--query-gpu=index")
            .arg("--format=csv,noheader,nounits")
            .output()
            .map(|o| o.status.success())
            .unwrap_or(false)
    }
    
    fn check_rocm() -> bool {
        Command::new("rocm-smi")
            .arg("--query-gpu=Utilization-Gpu")
            .arg("--showonly")
            .output()
            .map(|o| o.status.success())
            .unwrap_or(false)
    }
    
    fn check_amdgpu() -> bool {
        fs::metadata("/sys/class/drm/card0/device/gpu_busy_percent").is_ok()
    }
    
    fn check_intel() -> bool {
        fs::metadata("/sys/class/drm/card0/device/uvm/render_busy_ms").is_ok()
    }
}
```

## Error Types

```rust
#[derive(Debug, Error)]
pub enum GpuError {
    #[error("No GPU detected")]
    NoGpuDetected,
    
    #[error("Command failed: {0}")]
    CommandFailed(String),
    
    #[error("nvidia-smi error: {0}")]
    NvidiaSmIError(String),
    
    #[error("rocm-smi error: {0}")]
    RocmSmiError(String),
    
    #[error("I/O error: {0}")]
    IoError(#[from] io::Error),
    
    #[error("Invalid GPU path: {0}")]
    InvalidPath(PathBuf),
    
    #[error("Parse error: {0}")]
    ParseError(#[from] ParseIntError),
}
```

## Performance Considerations

### NVIDIA (nvidia-smi)

- **Overhead**: ~10-50ms per call
- **Frequency**: Safe to call every 1-5 seconds
- **Caching**: Can cache results between calls to reduce overhead

### AMD (sysfs)

- **Overhead**: ~1ms per call (direct file read)
- **Frequency**: Safe to call every 1 second
- **No external dependencies**

### Intel (sysfs)

- **Overhead**: ~1ms per call (direct file read)
- **Frequency**: Safe to call every 1 second
- **No external dependencies**

### ROCm (rocm-smi)

- **Overhead**: ~10-50ms per call
- **Frequency**: Safe to call every 1-5 seconds
- **Caching**: Can cache results between calls

## Testing

### Unit Test Example

```rust
#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_nvidia_smi_parsing() {
        let output = b" 75%\n 90%\n 45%\n";
        
        let average = parse_nvidia_output(output);
        assert!((average - 70.0).abs() < 0.01); // (75 + 90 + 45) / 3 = 70
    }
    
    #[test]
    fn test_amdgpu_parsing() {
        let content = "85\n";
        
        let usage = content.trim().parse::<f64>().unwrap();
        assert_eq!(usage, 85.0);
    }
}
```

## References

- [NVIDIA-SMI Manual](https://linux.die.net/man/8/nvidia-smi)
- [AMDGPU Documentation](https://www.kernel.org/doc/html/latest/driver-api/driver-base/subsys-amdgpu-gpu.html)
- [Intel i915 Driver](https://wiki.archlinux.org/title/Intel_graphics)
- [AMD ROCm Documentation](https://rocm.docs.amd.io/)

## Summary

GPU metrics collection is handled through multiple data sources depending on GPU vendor:
- **NVIDIA**: Primary source via `nvidia-smi` command-line tool
- **AMD**: Sysfs interface at `/sys/class/drm/` for open-source drivers, or `rocm-smi` for ROCm
- **Intel**: Sysfs interface at `/sys/class/drm/` for i915 driver

The collector implements automatic detection and fallback between sources, supporting both single-GPU and multi-GPU systems by averaging utilization across all detected GPUs.
