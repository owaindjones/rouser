# Network I/O Metrics

## Overview

The `rouser` daemon collects network I/O metrics by reading from the `/proc/net/dev` file. This provides aggregate network throughput (bytes sent/received) across all network interfaces on the system.

## Metric Details

### Primary Metric

| Metric | Type | Unit | Description |
|--------|------|------|-------------|
| `network_io` | Throughput | KB/s or MB/s | Total network throughput (RX + TX) |

**Alternative representation**:
| Metric | Type | Unit | Description |
|--------|------|------|-------------|
| `network_rx` | Throughput | KB/s or MB/s | Network receive throughput |
| `network_tx` | Throughput | KB/s or MB/s | Network transmit throughput |

### Derived Metrics

| Metric | Type | Unit | Description |
|--------|------|------|-------------|
| `network_total` | Throughput | KB/s or MB/s | Combined RX + TX throughput |

## Data Source: `/proc/net/dev`

### File Format

The `/proc/net/dev` file contains network device statistics in the following format:

```
Inter-|   Receive                                                |  Transmit
 face |bytes    packets errs drop fifo frame compressed multicast|bytes    packets errs drop fifo colls carrier compressed
    lo: 1234567 12345  0   0    0     0          0         0  1234567 12345  0   0    0     0       0          0
  eth0: 7654321 98765  1   2    0     0          0          5  4321098 87654  0   0    0     1       0          0
  eth1: 2468024 56789  0   0    0     0          0          0  1357901 45678  0   0    0     0       0          0
docker0: 111111 1111  0   0    0     0          0          0  222222 2222  0   0    0     0       0          0
```

### Field Descriptions

#### Header Lines (lines 1-2)

These lines contain column headers and are skipped during parsing.

#### Interface Lines (line 3+)

Each line represents a network interface with the following fields:

| Position | Field | Description |
|----------|-------|-------------|
| 0 | Interface name | Interface name (e.g., `lo`, `eth0`, `wlan0`) |
| 1 | RX bytes | Total bytes received |
| 2 | RX packets | Total packets received |
| 3 | RX errors | Receive errors |
| 4 | RX dropped | Dropped packets |
| 5 | RX fifo | FIFO buffer errors |
| 6 | RX frame | Framing errors |
| 7 | RX compressed | Compressed packets |
| 8 | RX multicast | Multicast packets |
| 9 | TX bytes | Total bytes transmitted |
| 10 | TX packets | Total packets transmitted |
| 11 | TX errors | Transmit errors |
| 12 | TX dropped | Dropped packets |
| 13 | TX fifo | FIFO buffer errors |
| 14 | TX colls | Collisions |
| 15 | TX carrier | Carrier errors |
| 16 | TX compressed | Compressed packets |

### Parsing Algorithm

```rust
struct InterfaceStats {
    name: String,
    rx_bytes: u64,
    rx_packets: u64,
    rx_errors: u64,
    rx_dropped: u64,
    rx_fifo: u64,
    rx_frame: u64,
    rx_compressed: u64,
    rx_multicast: u64,
    tx_bytes: u64,
    tx_packets: u64,
    tx_errors: u64,
    tx_dropped: u64,
    tx_fifo: u64,
    tx_colls: u64,
    tx_carrier: u64,
    tx_compressed: u64,
}

fn parse_net_dev_line(line: &str) -> Result<InterfaceStats> {
    let parts: Vec<&str> = line.split_whitespace().collect();
    
    if parts.len() < 17 {
        return Err(ParseError::InvalidFormat);
    }
    
    Ok(InterfaceStats {
        name: parts[0].trim_end_matches(':').to_string(),
        rx_bytes: parts[1].parse()?,
        rx_packets: parts[2].parse()?,
        rx_errors: parts[3].parse()?,
        rx_dropped: parts[4].parse()?,
        rx_fifo: parts[5].parse()?,
        rx_frame: parts[6].parse()?,
        rx_compressed: parts[7].parse()?,
        rx_multicast: parts[8].parse()?,
        tx_bytes: parts[9].parse()?,
        tx_packets: parts[10].parse()?,
        tx_errors: parts[11].parse()?,
        tx_dropped: parts[12].parse()?,
        tx_fifo: parts[13].parse()?,
        tx_colls: parts[14].parse()?,
        tx_carrier: parts[15].parse()?,
        tx_compressed: parts[16].parse()?,
    })
}
```

## Throughput Calculation

### Two-Sample Method

To calculate network throughput (MB/s or KB/s), we use a two-sample approach similar to CPU metrics:

```rust
pub struct NetworkCollector {
    last_stats: HashMap<String, InterfaceStats>,
    last_time: SystemTime,
}

impl NetworkCollector {
    pub async fn collect_network_io(&mut self) -> Result<NetworkMetrics> {
        let current_stats = self.read_net_dev().await?;
        let current_time = SystemTime::now();
        
        // Calculate time delta
        let delta = current_time.duration_since(self.last_time)
            .unwrap_or(Duration::from_secs(0));
        
        let mut total_rx_rate = 0.0;
        let mut total_tx_rate = 0.0;
        
        // For each interface we've seen before
        for (name, new_stats) in &current_stats {
            if let Some(old_stats) = self.last_stats.get(name) {
                // Calculate bytes difference
                let rx_delta = new_stats.rx_bytes.saturating_sub(old_stats.rx_bytes);
                let tx_delta = new_stats.tx_bytes.saturating_sub(old_stats.tx_bytes);
                
                // Calculate rate in bytes per second
                let rx_rate = (rx_delta as f64) / (delta.as_secs_f64());
                let tx_rate = (tx_delta as f64) / (delta.as_secs_f64());
                
                total_rx_rate += rx_rate;
                total_tx_rate += tx_rate;
            }
        }
        
        // Convert to KB/s or MB/s
        let rx_kb_s = total_rx_rate / 1024.0;
        let tx_kb_s = total_tx_rate / 1024.0;
        let rx_mb_s = rx_kb_s / 1024.0;
        let tx_mb_s = tx_kb_s / 1024.0;
        
        // Update last stats and time
        self.last_stats = current_stats;
        self.last_time = current_time;
        
        Ok(NetworkMetrics {
            rx_rate_kb_s: rx_kb_s,
            tx_rate_kb_s: tx_kb_s,
            rx_rate_mb_s: rx_mb_s,
            tx_rate_mb_s: tx_mb_s,
            total_rate_kb_s: (rx_kb_s + tx_kb_s),
            total_rate_mb_s: (rx_mb_s + tx_mb_s),
        })
    }
}
```

### Complete Implementation

```rust
use std::collections::HashMap;
use std::fs;
use std::time::{Duration, SystemTime};

#[derive(Debug, Clone, Default)]
pub struct InterfaceStats {
    pub rx_bytes: u64,
    pub rx_packets: u64,
    pub tx_bytes: u64,
    pub tx_packets: u64,
}

#[derive(Debug, Clone, Default)]
pub struct NetworkMetrics {
    pub rx_rate_kb_s: f64,
    pub tx_rate_kb_s: f64,
    pub rx_rate_mb_s: f64,
    pub tx_rate_mb_s: f64,
    pub total_rate_kb_s: f64,
    pub total_rate_mb_s: f64,
}

pub struct NetworkCollector {
    last_stats: HashMap<String, InterfaceStats>,
    last_time: SystemTime,
    include_interfaces: Option<Vec<String>>,
    exclude_interfaces: Vec<String>,
}

impl NetworkCollector {
    pub fn new() -> Self {
        Self {
            last_stats: HashMap::new(),
            last_time: SystemTime::UNIX_EPOCH,
            include_interfaces: None,
            exclude_interfaces: vec!["lo".to_string()], // Exclude loopback by default
        }
    }
    
    pub fn with_excluded_interfaces(mut self, interfaces: Vec<String>) -> Self {
        self.exclude_interfaces = interfaces;
        self
    }
    
    pub async fn collect_network_io(&mut self) -> Result<NetworkMetrics> {
        let current_stats = self.read_net_dev().await?;
        let current_time = SystemTime::now();
        
        let delta = match current_time.duration_since(self.last_time) {
            Ok(d) => d,
            Err(_) => Duration::from_secs(1), // Handle wraparound or first call
        };
        
        let delta_secs = delta.as_secs_f64();
        if delta_secs < 0.001 {
            // Avoid division by very small numbers
            return Ok(NetworkMetrics::default());
        }
        
        let mut total_rx_rate = 0.0;
        let mut total_tx_rate = 0.0;
        
        for (name, new_stats) in &current_stats {
            // Skip excluded interfaces
            if self.exclude_interfaces.contains(name) {
                continue;
            }
            
            // Apply include filter if set
            if let Some(ref include) = self.include_interfaces {
                if !include.contains(name) {
                    continue;
                }
            }
            
            if let Some(old_stats) = self.last_stats.get(name) {
                let rx_delta = new_stats.rx_bytes.saturating_sub(old_stats.rx_bytes);
                let tx_delta = new_stats.tx_bytes.saturating_sub(old_stats.tx_bytes);
                
                let rx_rate = (rx_delta as f64) / delta_secs;
                let tx_rate = (tx_delta as f64) / delta_secs;
                
                total_rx_rate += rx_rate;
                total_tx_rate += tx_rate;
            }
        }
        
        let rx_kb_s = total_rx_rate / 1024.0;
        let tx_kb_s = total_tx_rate / 1024.0;
        
        // Update for next iteration
        self.last_stats = current_stats;
        self.last_time = current_time;
        
        Ok(NetworkMetrics {
            rx_rate_kb_s: rx_kb_s,
            tx_rate_kb_s: tx_kb_s,
            rx_rate_mb_s: rx_kb_s / 1024.0,
            tx_rate_mb_s: tx_kb_s / 1024.0,
            total_rate_kb_s: rx_kb_s + tx_kb_s,
            total_rate_mb_s: (rx_kb_s + tx_kb_s) / 1024.0,
        })
    }
    
    fn read_net_dev(&self) -> Result<HashMap<String, InterfaceStats>> {
        let content = fs::read_to_string("/proc/net/dev")
            .map_err(|e| NetworkError::IoError(e.to_string()))?;
        
        let mut stats = HashMap::new();
        
        for line in content.lines() {
            // Skip header lines
            if line.contains("Inter-") || line.contains("face") {
                continue;
            }
            
            // Skip empty lines
            if line.trim().is_empty() {
                continue;
            }
            
            match parse_net_dev_line(line) {
                Ok(stats) => {
                    stats.insert(stats.name.clone(), stats);
                }
                Err(_) => {
                    // Skip malformed lines
                    continue;
                }
            }
        }
        
        Ok(stats)
    }
}

fn parse_net_dev_line(line: &str) -> Result<(String, InterfaceStats)> {
    let parts: Vec<&str> = line.split_whitespace().collect();
    
    if parts.len() < 17 {
        return Err(NetworkError::InvalidFormat);
    }
    
    let name = parts[0].trim_end_matches(':').to_string();
    
    Ok((
        name,
        InterfaceStats {
            rx_bytes: parts[1].parse()?,
            rx_packets: parts[2].parse()?,
            tx_bytes: parts[9].parse()?,
            tx_packets: parts[10].parse()?,
        },
    ))
}
```

## Configuration Options

### Interface Filtering

```rust
// Exclude specific interfaces
let collector = NetworkCollector::new()
    .with_excluded_interfaces(vec!["lo".to_string(), "docker0".to_string()]);

// Only include specific interfaces
collector.include_interfaces = vec!["eth0".to_string(), "wlan0".to_string()];
```

### Rate Units

```rust
// Available units
enum RateUnit {
    BytesPerSec,
    KBPerSec,
    MBPerSec,
    GBytesPerSec,
}

// For configuration, default to Mbps
let threshold_mbps: f64 = 100.0; // 100 Mbps
```

## Edge Cases and Considerations

### 1. First Sample

On first read, we can't calculate throughput (no baseline). Solution:

```rust
// First read: initialize values, return 0 throughput
// Second read onwards: calculate throughput from deltas
```

### 2. Counter Wraparound

Network byte counters can wrap around (u64 max). Solution:

```rust
// Handle wraparound using saturating_sub
let rx_delta = new_stats.rx_bytes.saturating_sub(old_stats.rx_bytes);

// Or check for wraparound manually
if new_bytes < old_bytes {
    // Counter wrapped around
    rx_delta = u64::MAX - old_bytes + new_bytes + 1;
}
```

### 3. Interface State Changes

Network interfaces can come and go. The collector handles this naturally:

- New interfaces: First sample initializes them, subsequent samples calculate rate
- Removed interfaces: Simply stop being included in calculations

### 4. Virtual Interfaces

Virtual interfaces (Docker, bridges, tunnels) may have different characteristics:

- Docker bridges: Can have high throughput with low latency
- Tunnels (wireguard, openvpn): May show encapsulation overhead
- Can filter these out if needed using interface exclusion list

### 5. Polling Interval

Recommended polling intervals:

| Interval | Use Case |
|----------|----------|
| 1s | High-frequency monitoring |
| 2-5s | Default, balanced |
| 10s | Low-frequency, low-overhead |

Shorter intervals provide better responsiveness but may miss brief bursts.

## Alternative Sources

### iproute2 (ip command)

```bash
# Get interface statistics
ip -s link show

# Detailed statistics with counters
ip -s -s link show eth0
```

**Pros**: More detailed information
**Cons**: Slower than /proc/net/dev, requires parsing

### netlink sockets

```rust
use rtnetlink::{Handle, Connection, Transport};

// Requires rtnetlink crate
// More complex but provides real-time updates
```

**Pros**: Real-time updates without polling
**Cons**: More complex implementation, requires additional dependencies

### sysstat/iostat

```bash
# System statistics tools
sar -n DEV 1 5

# Or with iostat
iostat -n 1 5
```

**Pros**: Rich statistical data
**Cons**: External dependency, parsing overhead

## Performance Considerations

- **File I/O**: Reading `/proc/net/dev` is very fast (no disk I/O, all in memory)
- **Parsing**: Minimal overhead from string splitting and parsing
- **Memory**: O(n) where n is number of network interfaces (typically < 10)
- **CPU usage**: Negligible for typical polling intervals

## Testing

### Unit Test Example

```rust
#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_parse_net_dev_line() {
        let line = "  eth0: 1000000 1000 0 0 0 0 0 0 2000000 2000 0 0 0 0 0 0";
        let (name, stats) = parse_net_dev_line(line).unwrap();
        
        assert_eq!(name, "eth0");
        assert_eq!(stats.rx_bytes, 1_000_000);
        assert_eq!(stats.tx_bytes, 2_000_000);
    }
    
    #[test]
    fn test_throughput_calculation() {
        let mut collector = NetworkCollector::new();
        
        // Simulate first read
        collector.collect_network_io().unwrap();
        
        // Simulate second read after 1 second with increased bytes
        // (In real code, this would actually read /proc/net/dev)
        // For testing, we'd mock the read_net_dev method
    }
}
```

### Integration Test

```rust
#[test]
fn test_real_network_metrics() {
    let mut collector = NetworkCollector::new();
    
    let _ = collector.collect_network_io(); // First sample
    std::thread::sleep(Duration::from_secs(1));
    
    let metrics = collector.collect_network_io().unwrap();
    
    assert!(metrics.total_rate_kb_s >= 0.0);
}
```

## Configuration Reference

### Threshold Configuration

```yaml
thresholds:
  # Network I/O threshold in Mbps
  network_io: 100.0
  
  # Optional: separate RX/TX thresholds
  network_rx: 50.0   # Mbps receive
  network_tx: 50.0   # Mbps transmit
```

### Interface Filtering

```yaml
network:
  # Interfaces to exclude from monitoring
  exclude:
    - lo
    - docker0
    - veth*
  
  # Interfaces to include (if not set, monitor all except excluded)
  include:
    - eth0
    - enp1s0
```

## Summary

Network I/O metrics are collected from `/proc/net/dev`, which provides comprehensive network interface statistics. The primary metric is aggregate network throughput calculated from the difference in RX/TX bytes between two sampling intervals. This approach:

- Requires no external dependencies
- Provides real-time network activity data
- Supports multiple network interfaces
- Handles virtual interfaces and dynamic interface changes
- Can filter interfaces via configuration

The implementation uses a two-sample approach to calculate bytes-per-second rates, which are then converted to KB/s or MB/s based on configuration preferences.
