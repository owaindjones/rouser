# Rouser Quick Start Guide

## Getting Started

This guide helps you get rouser running on your system in minutes.

## Prerequisites

- Linux system with systemd
- Rust toolchain (rustc, cargo)
- D-Bus system bus access
- Root or sudo privileges

## Installation Steps

### 1. Clone the Repository

```bash
cd /home/sandbox/code-assistant/code/rouser
git clone https://github.com/your-org/rouser.git
cd rouser
```

### 2. Build the Project

```bash
cargo build --release
```

This creates the binary at `target/release/rouser`

### 3. Create Configuration

```bash
sudo mkdir -p /etc/rouser
sudo cp config.example.yaml /etc/rouser/config.yaml
```

Edit the configuration:

```bash
sudo nano /etc/rouser/config.yaml
```

### 4. Install Binary

```bash
sudo cp target/release/rouser /usr/bin/rouser
sudo chmod +x /usr/bin/rouser
```

### 5. Create Systemd Service

```bash
sudo cp rouser.service /etc/systemd/system/rouser.service
sudo systemctl daemon-reload
```

### 6. Enable and Start

```bash
sudo systemctl enable rouser
sudo systemctl start rouser
```

### 7. Verify Status

```bash
sudo systemctl status rouser
```

## Configuration

### Minimal Configuration

Create `/etc/rouser/config.yaml`:

```yaml
daemon:
  name: "rouser"
  update_interval: 5s
  log_level: info

thresholds:
  cpu_usage: 80.0
  network_io: 100.0

timing:
  duration_threshold: 30s
  idle_duration: 60s

inhibition:
  what: "sleep,hibernate,shutdown"
  mode: "block"
```

### Common Threshold Values

| Metric | Conservative | Aggressive | Use Case |
|--------|-------------|------------|----------|
| CPU | 90% | 70% | High-load servers |
| GPU | 95% | 80% | Workstation |
| Network | 200 Mbps | 50 Mbps | Network-intensive |
| Disk | 100 MB/s | 25 MB/s | I/O-intensive |

## Testing

### Dry Run

```bash
rouser --test-config /etc/rouser/config.yaml
```

### Manual Testing

```bash
# Check if inhibition works
systemd-inhibit --what=sleep --mode=delay "sleep 300"

# Try to suspend (should be delayed)
systemctl suspend

# Release inhibition
# (exit the sleep command or Ctrl+C)
```

### Check Inhibitors

```bash
loginctl list-inhibitors
```

## Troubleshooting

### Permission Denied

**Symptom**: `Access denied` error

**Solution**: Add user to login group

```bash
sudo usermod -a -G login $USER
```

### Configuration Error

**Symptom**: Configuration validation fails

**Solution**: Check config syntax

```bash
rouser --validate-config /etc/rouser/config.yaml
```

### Service Not Starting

**Symptom**: `systemctl status rouser` shows failed

**Solution**: Check logs

```bash
journalctl -u rouser -f
```

### High CPU Usage

**Symptom**: rouser uses too much CPU

**Solution**: Increase update interval

```yaml
daemon:
  update_interval: 10s
```

## Development Setup

### Create Development Workspace

```bash
mkdir -p ~/code/rouser
cd ~/code/rouser
```

### Initialize Git

```bash
git init
```

### Create Project Structure

```bash
mkdir -p src
touch Cargo.toml
touch README.md
```

### Add Dependencies

```toml
[package]
name = "rouser"
version = "0.1.0"
edition = "2021"

[dependencies]
zbus = "4"
tokio = { version = "1", features = ["full"] }
serde = { version = "1", features = ["derive"] }
serde_yaml = "0.9"
log = "0.4"
env_logger = "0.10"
```

## Next Steps

1. **Read the Architecture Guide** - Understand system design
2. **Review Configuration Reference** - Learn all options
3. **Study D-Bus API Documentation** - Understand sleep inhibition
4. **Start Implementation** - Begin with metric collection

## Resources

- **Architecture Guide**: `ARCHITECTURE.md`
- **Configuration Reference**: `CONFIGURATION_REFERENCE.md`
- **D-Bus API Docs**: `DBUS_SLEEP_INHIBITION_API.md`
- **Official Rust Docs**: https://rust-lang.org
- **zbus Documentation**: https://docs.rs/zbus/

## Common Commands

```bash
# Build
cargo build --release

# Run locally
cargo run -- --config config.yaml

# Install
sudo cp target/release/rouser /usr/bin/rouser

# Service control
sudo systemctl start rouser
sudo systemctl stop rouser
sudo systemctl restart rouser
sudo systemctl status rouser

# Logs
journalctl -u rouser -f
```

## Support

For issues and questions:
- Check logs: `journalctl -u rouser`
- Review configuration: `rouser --validate-config`
- Read documentation in planning directory
