# Systemd Service Configuration

## Service File Location

The rouser systemd service file should be installed to:
```
/etc/systemd/system/rouser.service
```

## Service File Template

```ini
[Unit]
Description=Rouser - Sleep Inhibition Daemon
Documentation=https://github.com/yourusername/rouser
After=network.target
Wants=network.target

[Service]
Type=simple
ExecStart=/usr/bin/rouser --config /etc/rouser/config.toml
Restart=on-failure
RestartSec=5
StandardOutput=journal
StandardError=journal
SyslogIdentifier=rouser

# Security hardening
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=read-only
PrivateTmp=true
ReadWritePaths=/var/log/rouser

# Resource limits
MemoryLimit=128M
CPUQuota=25%

# User/Group
User=root
Group=root

[Install]
WantedBy=multi-user.target
```

## Configuration Directory

Create configuration directory:
```bash
sudo mkdir -p /etc/rouser
sudo chown root:root /etc/rouser
sudo chmod 750 /etc/rouser
```

## Default Configuration Template

```bash
sudo mkdir -p /etc/rouser
sudo cp /usr/share/rouser/config.example.toml /etc/rouser/config.toml
```

## Enabling the Service

```bash
# Enable service to start on boot
sudo systemctl enable rouser

# Start the service
sudo systemctl start rouser

# Check status
sudo systemctl status rouser

# View logs
sudo journalctl -u rouser -f
```

## Logging

The service logs to journald with identifier `rouser`. To view logs:

```bash
# All logs
sudo journalctl -u rouser

# Follow logs in real-time
sudo journalctl -u rouser -f

# Logs since boot
sudo journalctl -u rouser -b

# Last 100 lines
sudo journalctl -u rouser -n 100
```

## Logrotate (Optional)

If you want to limit log size, create `/etc/logrotate.d/rouser`:

```
/var/log/rouser/*.log {
    daily
    rotate 7
    compress
    delaycompress
    missingok
    notifempty
    create 0640 root root
}
```

## D-Bus Permissions

The service needs access to the system D-Bus to call `org.freedesktop.login1`. This is typically available by default for root, but if running as a non-root user, you may need to add it to the `messagebus` group or configure polkit rules.

## Environment Variables

You can override configuration via environment variables:

```ini
[Service]
Environment="ROUSER_LOG_LEVEL=debug"
Environment="ROUSER_CONFIG_PATH=/etc/rouser/config.toml"
```

Then in your config:
```toml
log_level = "${ROUSER_LOG_LEVEL}"
config_path = "${ROUSER_CONFIG_PATH}"
```
